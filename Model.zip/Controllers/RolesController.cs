﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Recruitment.Data;
using Recruitment.Model.Entity;

namespace Recruitment.Controllers
{
    [Route("api/RolesController")]
    [ApiController]
    public class RolesController : Controller
    {

        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public RolesController(ApplicationDbContext dbContext, IConfiguration configuration)
        {
            this._context = dbContext;
            _configuration = configuration;
            _configuration = configuration;
        }

        [HttpPost("save")]
        public async Task<IActionResult> SaveRole([FromBody] SaveRoleRequest request)
        {
            if (request.RoleId < 0)
                return BadRequest(new
                {
                    message = "Invalid RoleId."
                });

            if (request.CompanyId <= 0)
                return BadRequest(new
                {
                    message = "A valid CompanyId is required."
                });

            var roleName = request.RoleName?.Trim();

            if (string.IsNullOrWhiteSpace(roleName))
                return BadRequest(new
                {
                    message = "Role name is required."
                });

            if (roleName.Length > 150)
                return BadRequest(new
                {
                    message = "Role name cannot exceed 150 characters."
                });

            bool isNew = request.RoleId == 0;

            var userId = isNew
                ? request.CreatedBy
                : request.ModifiedBy;

            if (userId.HasValue && userId.Value <= 0)
                return BadRequest(new
                {
                    message = "Invalid creator or modifier user ID."
                });

            Role role;

            if (isNew)
            {
                role = new Role
                {
                    CompanyId = request.CompanyId,
                    
                };
            }
            else
            {
                // Editing cannot move a role into another company.
                var existing = await _context.Roles
                    .FirstOrDefaultAsync(r =>
                        r.RoleId == request.RoleId &&
                        r.CompanyId == request.CompanyId);

                if (existing == null)
                    return NotFound(new
                    {
                        message = "Role not found for this company."
                    });

                role = existing;
            }

            // Includes inactive roles and excludes the edited role.
            // Case-insensitive after applying the migration.
            var duplicate = await _context.Roles.AnyAsync(r =>
                r.CompanyId == request.CompanyId &&
                r.RoleName == roleName &&
                r.RoleId != request.RoleId);

            if (duplicate)
                return Conflict(new
                {
                    message = "Role name already exists in this company."
                });

            role.RoleName = roleName;
            role.IsActive = request.IsActive;

            if (isNew)
            {
                role.CreatedOn = DateTime.UtcNow;
                role.CreatedBy = request.CreatedBy;

                _context.Roles.Add(role);
            }
            else
            {
                role.ModifiedOn = DateTime.UtcNow;
                role.ModifiedBy = request.ModifiedBy;
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
                when (ex.InnerException is SqlException sql &&
                      (sql.Number == 2601 || sql.Number == 2627))
            {
                return Conflict(new
                {
                    message = "A role with these unique details already exists."
                });
            }

            return StatusCode(isNew ? 201 : 200, new
            {
                message = isNew
                    ? "Role created successfully."
                    : "Role updated successfully.",
                data = role
            });
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetRoles( [FromQuery] int companyId)
        {
            if (companyId <= 0)
                return BadRequest(new
                {
                    message = "A valid CompanyId is required."
                });

            var roles = await _context.Roles
                .AsNoTracking()
                .Where(r => r.CompanyId == companyId)
                .OrderByDescending(r => r.RoleId)
                .Select(r => new
                {
                    r.RoleId,
                    r.RoleName,
                    r.CompanyId,
                  
                    r.IsActive,
                    r.CreatedOn,
                    r.CreatedBy,
                    r.ModifiedOn,
                    r.ModifiedBy
                })
                .ToListAsync();

            return Ok(new
            {
                message = "Roles fetched successfully.",
                data = roles
            });
        }


        [HttpDelete("delete/{roleId:int}")]
        public async Task<IActionResult> DeleteRole(
    int roleId,
    [FromQuery] int companyId)
        {
            if (roleId <= 0 || companyId <= 0)
                return BadRequest(new
                {
                    message = "Valid RoleId and CompanyId are required."
                });

            await using var transaction =
                await _context.Database.BeginTransactionAsync(
                    System.Data.IsolationLevel.Serializable);

            var role = await _context.Roles.FirstOrDefaultAsync(r =>
                r.RoleId == roleId &&
                r.CompanyId == companyId);

            if (role == null)
                return NotFound(new
                {
                    message = "Role not found for this company."
                });

            var isUsed = await _context.EmployeeMasters
                .AnyAsync(e => e.RoleId == roleId);

            if (isUsed)
                return Conflict(new
                {
                    message = "Cannot delete this role because it is used in EmployeeMaster."
                });

            _context.Roles.Remove(role);

            try
            {
                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
            }
            catch (DbUpdateException ex)
                when (ex.InnerException is SqlException sql &&
                      sql.Number == 547)
            {
                await transaction.RollbackAsync();

                return Conflict(new
                {
                    message = "Cannot delete this role because related records reference it."
                });
            }

            return Ok(new
            {
                message = "Role deleted successfully."
            });
        }
        public class SaveRoleRequest
        {
            public int RoleId { get; set; }
            public string? RoleName { get; set; }
            public int CompanyId { get; set; }
            public int? CreatedBy { get; set; }
            public int? ModifiedBy { get; set; }
            public bool IsActive { get; set; } = true;
        }
    }
}
