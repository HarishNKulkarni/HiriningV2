﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Recruitment.Data;
using Recruitment.Model.Entity;


namespace IMS.Controllers
{
    [Route("api/EmployeeController")]
    [ApiController]
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public EmployeeController(ApplicationDbContext dbContext, IConfiguration configuration)
        {
            this._context = dbContext;
            _configuration = configuration;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("CreateEmployee")]
        public IActionResult CreateEmployee([FromBody] CreateEmployeeRequest request)
        {
            try
            {
                if (request == null)
                    return Ok(new { Status = false, Message = "Invalid request" });

                if (string.IsNullOrWhiteSpace(request.FirstName))
                    return Ok(new { Status = false, Message = "FirstName is required" });

                if (request.CompanyId <= 0)
                    return Ok(new { Status = false, Message = "CompanyId is required" });

                if (request.BranchId <= 0)
                    return Ok(new { Status = false, Message = "BranchId is required" });

                if (string.IsNullOrWhiteSpace(request.Password))
                    return Ok(new { Status = false, Message = "Password is required" });

                if (string.IsNullOrWhiteSpace(request.Mobilenumber))
                    return Ok(new { Status = false, Message = "Mobilenumber is required" });

                if (string.IsNullOrWhiteSpace(request.Email))
                    return Ok(new { Status = false, Message = "Email is required" });

                // Validate EmpCode if provided
                if (!string.IsNullOrWhiteSpace(request.EmpCode))
                {
                    var normalizedEmpCode = request.EmpCode
                        .Trim()
                        .Replace(" ", "")
                        .ToLower();

                    var empCodeExists = _context.EmployeeMasters.Any(x =>
                        x.EmpCode != null && x.CompanyId == request.CompanyId&&
                        x.EmpCode
                            .Trim()
                            .Replace(" ", "")
                            .ToLower() == normalizedEmpCode &&
                        x.IsActive != false);

                    if (empCodeExists)
                    {
                        return Ok(new
                        {
                            Status = false,
                            Message = "Employee Code already exists"
                        });
                    }
                }
                if (string.IsNullOrWhiteSpace(request.EmpCode))
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "EmployeeCode is required"
                    });
                }

                var normalizedEmployeeCode =
                    NormalizeEmployeeCode(request.EmpCode);

                var existingEmployeeCodes = _context.EmployeeMasters
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.IsActive &&
                        x.EmpCode != null)
                    .Select(x => x.EmpCode)
                    .ToList();

                var duplicateEmployeeCode = existingEmployeeCodes
                    .Any(x =>
                        NormalizeEmployeeCode(x) == normalizedEmployeeCode);

                if (duplicateEmployeeCode)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message =
                            $"EmployeeCode '{request.EmpCode.Trim()}' already exists for this company"
                    });
                }

                if (!DateTime.TryParse(request.DateOfJoining, out DateTime employeeJoiningDate))
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Invalid DateOfJoining"
                    });
                }

                var company = _context.Companys
                    .FirstOrDefault(x => x.CompanyID == request.CompanyId);

                if (company == null)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Company not found"
                    });
                }

                var branch = _context.Branches
                    .FirstOrDefault(x =>
                        x.BranchId == request.BranchId &&
                        x.CompanyId == request.CompanyId &&
                        x.IsActive);

                if (branch == null)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Branch not found"
                    });
                }

                if (!company.CreatedOn.HasValue)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Company creation date not found"
                    });
                }

                if (!branch.CreatedOn.HasValue)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Branch creation date not found"
                    });
                }

                DateTime minimumAllowedDate =
                    company.CreatedOn.Value.Date > branch.CreatedOn.Value.Date
                        ? company.CreatedOn.Value.Date
                        : branch.CreatedOn.Value.Date;

                //if (employeeJoiningDate.Date < minimumAllowedDate)
                //{
                //    return Ok(new
                //    {
                //        Status = false,
                //        Message = $"Employee joining date cannot be before {minimumAllowedDate:dd-MM-yyyy}"
                //    });
                //}
                // Validate PAN if provided
                if (!string.IsNullOrWhiteSpace(request.Pan))
                {
                    // Basic PAN validation (10 characters, alphanumeric)
                    if (request.Pan.Length != 10)
                        return Ok(new { Status = false, Message = "PAN must be exactly 10 characters" });

                    var panExists = _context.EmployeeMasters
                        .Any(x => x.Pan == request.Pan && x.IsActive);

                    if (panExists)
                        return Ok(new { Status = false, Message = "PAN already exists" });
                }

                // Validate Aadhar if provided
                if (!string.IsNullOrWhiteSpace(request.Adhar))
                {
                    // Basic Aadhar validation (12 digits)
                    if (!System.Text.RegularExpressions.Regex.IsMatch(request.Adhar, @"^\d{12}$"))
                        return Ok(new { Status = false, Message = "Aadhar must be 12 digits" });

                    var adharExists = _context.EmployeeMasters
                        .Any(x => x.Adhar == request.Adhar && x.IsActive);

                    if (adharExists)
                        return Ok(new { Status = false, Message = "Aadhar already exists" });
                }

                // Validate Bank Account if provided
                if (!string.IsNullOrWhiteSpace(request.BankAccountNo))
                {
                    var bankAccountExists = _context.EmployeeMasters
                        .Any(x => x.BankAccountNo == request.BankAccountNo && x.IsActive);

                    if (bankAccountExists)
                        return Ok(new { Status = false, Message = "Bank Account Number already exists" });
                }

                // Validate IFSC if provided
                if (!string.IsNullOrWhiteSpace(request.IFSC))
                {
                    // Basic IFSC validation (11 characters, alphanumeric)
                    if (request.IFSC.Length != 11)
                        return Ok(new { Status = false, Message = "IFSC must be exactly 11 characters" });
                }

                DateTime? doj = null;

                if (!string.IsNullOrWhiteSpace(request.DateOfJoining))
                {
                    if (!DateTime.TryParseExact(
                            request.DateOfJoining,
                            "yyyy-MM-dd",
                            System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None,
                            out DateTime joiningDate))
                    {
                        return Ok(new
                        {
                            Status = false,
                            Message = "DateOfJoining must be in yyyy-MM-dd format"
                        });
                    }

                    doj = joiningDate;
                }

                var companyExists = _context.Companys
                    .Any(x => x.CompanyID == request.CompanyId);

                if (!companyExists)
                    return Ok(new { Status = false, Message = "Company not found" });

                var branchExists = _context.Branches
                    .Any(x => x.BranchId == request.BranchId
                           && x.CompanyId == request.CompanyId
                           && x.IsActive);

                if (!branchExists)
                    return Ok(new { Status = false, Message = "Branch not found for this company" });

                var mobileExists = _context.EmployeeMasters
                    .Any(x => x.Mobilenumber == request.Mobilenumber);

                if (mobileExists)
                    return Ok(new { Status = false, Message = "Mobile number already exists" });

                var emailExists = _context.EmployeeMasters
                    .Any(x => x.Email == request.Email);

                if (emailExists)
                    return Ok(new { Status = false, Message = "Email already exists" });

                var staticEncyKey = _configuration["EncryptionSettings:StaticUniqueId"];

                var encryptedPassword = Helper.Helper.EncryptAPIData(
                    request.Password,
                    staticEncyKey
                );

                var employee = new Recruitment.Model.Entity.Employee
                {
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    CompanyId = request.CompanyId,
                    BranchId = request.BranchId,
                    DepartmentId = request.DepartmentId,
                    Password = encryptedPassword,
                    Mobilenumber = request.Mobilenumber,
                    Email = request.Email,
                    Profile = request.Profile,
                    RoleId = request.RoleId,
                    City = request.City,
                    District = request.District,
                    State = request.State,
                    Location = request.Location,
                    DateOfJoining = doj,
                    EmergencyNumber = request.EmergencyNumber,
                    CreatedBy = request.CreatedBy,
                    CreatedOn = DateTime.Now,
                    IsActive = true,

                    // New fields
                    EmpCode = request.EmpCode,
                    Designation = request.Designation,
                    ReportingToManagerCode = request.ReportingToManagerCode,
                    Pan = request.Pan,
                    Adhar = request.Adhar,
                    BankName = request.BankName,
                    BankAccountNo = request.BankAccountNo,
                    IFSC = request.IFSC
                };

                _context.EmployeeMasters.Add(employee);
                _context.SaveChanges();

                return Ok(new
                {
                    Status = true,
                    Message = "Employee created successfully",
                    EmployeeId = employee.EmployeeId
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Status = false,
                    Message = ex.Message
                });
            }
        }


        public static string NormalizeEmployeeCode(string? employeeCode)
        {
            if (string.IsNullOrWhiteSpace(employeeCode))
                return string.Empty;

            return new string(
                employeeCode
                    .Where(char.IsLetterOrDigit)
                    .Select(char.ToLowerInvariant)
                    .ToArray());
        }
        [HttpPost]
        [Route("EditEmployee")]
        public IActionResult EditEmployee([FromBody] EditEmployeeRequest request)
        {
            try
            {
                if (request == null)
                    return Ok(new { Status = false, Message = "Invalid request" });

                if (request.EmployeeId <= 0)
                    return Ok(new { Status = false, Message = "EmployeeId is required" });

                if (string.IsNullOrWhiteSpace(request.FirstName))
                    return Ok(new { Status = false, Message = "FirstName is required" });

                if (request.BranchId <= 0)
                    return Ok(new { Status = false, Message = "BranchId is required" });

                if (request.DepartmentId <= 0)
                    return Ok(new { Status = false, Message = "DepartmentId is required" });

                if (string.IsNullOrWhiteSpace(request.Mobilenumber))
                    return Ok(new { Status = false, Message = "Mobilenumber is required" });

                if (string.IsNullOrWhiteSpace(request.Email))
                    return Ok(new { Status = false, Message = "Email is required" });

                var employee = _context.EmployeeMasters
                    .FirstOrDefault(x => x.EmployeeId == request.EmployeeId && x.IsActive);

                if (employee == null)
                    return Ok(new { Status = false, Message = "Employee not found" });

                // Validate EmpCode if provided and changed
                if (!string.IsNullOrWhiteSpace(request.EmpCode))
                {
                    if (request.EmpCode != employee.EmpCode)
                    {
                        var empCodeExists = _context.EmployeeMasters
                            .Any(x => x.EmpCode == request.EmpCode
                                   && x.EmployeeId != request.EmployeeId
                                   && x.IsActive);

                        if (empCodeExists)
                            return Ok(new { Status = false, Message = "Employee Code already exists" });
                    }
                }

                // Validate PAN if provided and changed
                if (!string.IsNullOrWhiteSpace(request.Pan))
                {
                    // Basic PAN validation (10 characters, alphanumeric)
                    if (request.Pan.Length != 10)
                        return Ok(new { Status = false, Message = "PAN must be exactly 10 characters" });

                    if (request.Pan != employee.Pan)
                    {
                        var panExists = _context.EmployeeMasters
                            .Any(x => x.Pan == request.Pan
                                   && x.EmployeeId != request.EmployeeId
                                   && x.IsActive);

                        if (panExists)
                            return Ok(new { Status = false, Message = "PAN already exists" });
                    }
                }

                // Validate Aadhar if provided and changed
                if (!string.IsNullOrWhiteSpace(request.Adhar))
                {
                    // Basic Aadhar validation (12 digits)
                    if (!System.Text.RegularExpressions.Regex.IsMatch(request.Adhar, @"^\d{12}$"))
                        return Ok(new { Status = false, Message = "Aadhar must be 12 digits" });

                    if (request.Adhar != employee.Adhar)
                    {
                        var adharExists = _context.EmployeeMasters
                            .Any(x => x.Adhar == request.Adhar
                                   && x.EmployeeId != request.EmployeeId
                                   && x.IsActive);

                        if (adharExists)
                            return Ok(new { Status = false, Message = "Aadhar already exists" });
                    }
                }

                // Validate Bank Account if provided and changed
                if (!string.IsNullOrWhiteSpace(request.BankAccountNo))
                {
                    if (request.BankAccountNo != employee.BankAccountNo)
                    {
                        var bankAccountExists = _context.EmployeeMasters
                            .Any(x => x.BankAccountNo == request.BankAccountNo
                                   && x.EmployeeId != request.EmployeeId
                                   && x.IsActive);

                        if (bankAccountExists)
                            return Ok(new { Status = false, Message = "Bank Account Number already exists" });
                    }
                }

                // Validate IFSC if provided
                if (!string.IsNullOrWhiteSpace(request.IFSC))
                {
                    // Basic IFSC validation (11 characters, alphanumeric)
                    if (request.IFSC.Length != 11)
                        return Ok(new { Status = false, Message = "IFSC must be exactly 11 characters" });
                }

                var branchExists = _context.Branches
                    .Any(x => x.BranchId == request.BranchId && x.IsActive == true);

                if (!branchExists)
                    return Ok(new { Status = false, Message = "Branch not found for this company" });

                var departmentExists = _context.Departments
                    .Any(x => x.DepartmentId == request.DepartmentId
                           && x.BranchId == request.BranchId
                           && x.IsActive);

                if (!departmentExists)
                    return Ok(new { Status = false, Message = "Department not found for this branch" });

                var mobileExists = _context.EmployeeMasters
                    .Any(x => x.Mobilenumber == request.Mobilenumber
                           && x.EmployeeId != request.EmployeeId);

                if (mobileExists)
                    return Ok(new { Status = false, Message = "Mobile number already exists" });

                var emailExists = _context.EmployeeMasters
                    .Any(x => x.Email == request.Email
                           && x.EmployeeId != request.EmployeeId);

                if (emailExists)
                    return Ok(new { Status = false, Message = "Email already exists" });

                DateTime? doj = null;

                if (!string.IsNullOrWhiteSpace(request.DateOfJoining))
                {
                    if (!DateTime.TryParseExact(
                            request.DateOfJoining,
                            "yyyy-MM-dd",
                            System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None,
                            out DateTime joiningDate))
                    {
                        return Ok(new
                        {
                            Status = false,
                            Message = "DateOfJoining must be in yyyy-MM-dd format"
                        });
                    }

                    doj = joiningDate;
                }

                employee.FirstName = request.FirstName;
                employee.LastName = request.LastName;
                employee.BranchId = request.BranchId;
                employee.DepartmentId = request.DepartmentId;
                employee.Mobilenumber = request.Mobilenumber;
                employee.Email = request.Email;
                employee.Profile = request.Profile;
                employee.City = request.City;
                employee.District = request.District;
                employee.State = request.State;
                employee.Location = request.Location;
                employee.DateOfJoining = doj;
                employee.EmergencyNumber = request.EmergencyNumber;
                employee.ModifiedBy = request.ModifiedBy;
                employee.ModifiedOn = DateTime.Now;

                // Update new fields if provided
                if (!string.IsNullOrWhiteSpace(request.EmpCode))
                    employee.EmpCode = request.EmpCode;

                if (!string.IsNullOrWhiteSpace(request.Designation))
                    employee.Designation = request.Designation;

                if (!string.IsNullOrWhiteSpace(request.ReportingToManagerCode))
                    employee.ReportingToManagerCode = request.ReportingToManagerCode;

                if (!string.IsNullOrWhiteSpace(request.Pan))
                    employee.Pan = request.Pan;

                if (!string.IsNullOrWhiteSpace(request.Adhar))
                    employee.Adhar = request.Adhar;

                if (!string.IsNullOrWhiteSpace(request.BankName))
                    employee.BankName = request.BankName;

                if (!string.IsNullOrWhiteSpace(request.BankAccountNo))
                    employee.BankAccountNo = request.BankAccountNo;

                if (!string.IsNullOrWhiteSpace(request.IFSC))
                    employee.IFSC = request.IFSC;

                if (!string.IsNullOrWhiteSpace(request.Password))
                {
                    var staticEncyKey = _configuration["EncryptionSettings:StaticUniqueId"];

                    employee.Password = Helper.Helper.EncryptAPIData(
                        request.Password,
                        staticEncyKey
                    );
                }

                _context.SaveChanges();

                return Ok(new
                {
                    Status = true,
                    Message = "Employee updated successfully"
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Status = false,
                    Message = ex.Message
                });
            }
        }

        [HttpPost("GetEmployeeList")]
        public async Task<IActionResult> GetEmployeeList(
       [FromBody] GetEmployeeListRequest? request)
        {
            if (request == null || request.CompanyId <= 0)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Valid CompanyId is required."
                });
            }

            if (request.BranchIds != null &&
                request.BranchIds.Any(id => id < 0))
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Branch IDs cannot be negative."
                });
            }

            if (request.DepartmentIds != null &&
                request.DepartmentIds.Any(id => id < 0))
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Department IDs cannot be negative."
                });
            }

            try
            {
                var company = await _context.Companys
                    .AsNoTracking()
                    .Where(x => x.CompanyID == request.CompanyId)
                    .Select(x => new
                    {
                        x.CompanyID,
                        x.CompanyName
                    })
                    .FirstOrDefaultAsync();

                if (company == null)
                {
                    return NotFound(new
                    {
                        Status = false,
                        Message = "Company not found."
                    });
                }

                bool allBranches =
                    request.BranchIds == null ||
                    request.BranchIds.Count == 0 ||
                    request.BranchIds.Contains(0);

                bool allDepartments =
                    request.DepartmentIds == null ||
                    request.DepartmentIds.Count == 0 ||
                    request.DepartmentIds.Contains(0);

                var selectedBranchIds = allBranches
                    ? Array.Empty<int>()
                    : request.BranchIds!.Distinct().ToArray();

                var selectedDepartmentIds = allDepartments
                    ? Array.Empty<int>()
                    : request.DepartmentIds!.Distinct().ToArray();

                if (!allBranches)
                {
                    var validBranchCount = await _context.Branches
                        .CountAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            selectedBranchIds.Contains(x.BranchId));

                    if (validBranchCount != selectedBranchIds.Length)
                    {
                        return BadRequest(new
                        {
                            Status = false,
                            Message = "One or more branches do not belong to this company."
                        });
                    }
                }

                if (!allDepartments)
                {
                    var validDepartmentCount = await _context.Departments
                        .CountAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            selectedDepartmentIds.Contains(x.DepartmentId));

                    if (validDepartmentCount != selectedDepartmentIds.Length)
                    {
                        return BadRequest(new
                        {
                            Status = false,
                            Message = "One or more departments do not belong to this company."
                        });
                    }
                }

                var query = _context.EmployeeMasters
                    .AsNoTracking()
                    .Where(x => x.CompanyId == request.CompanyId&&x.IsAdmin!=true&&x.IsActive!=false);

                if (!allBranches)
                {
                    query = query.Where(x =>
                        selectedBranchIds.Contains(x.BranchId));
                }

                if (!allDepartments)
                {
                    query = query.Where(x =>
                        selectedDepartmentIds.Any(id => id == x.DepartmentId));
                }

                var employees = await query
                    .OrderByDescending(x => x.EmployeeId)
                    .Select(x => new
                    {
                        x.EmployeeId,
                        x.EmpCode,
                        x.FirstName,
                        x.LastName,

                        EmployeeName =
                            ((x.FirstName ?? "") + " " +
                             (x.LastName ?? "")).Trim(),

                        x.CompanyId,
                        CompanyName = company.CompanyName,

                        x.BranchId,
                        BranchName = _context.Branches
                            .Where(b =>
                                b.BranchId == x.BranchId &&
                                b.CompanyId == x.CompanyId)
                            .Select(b => b.BranchName)
                            .FirstOrDefault(),

                        x.DepartmentId,
                        DepartmentName = _context.Departments
                            .Where(d =>
                                d.DepartmentId == x.DepartmentId &&
                                d.CompanyId == x.CompanyId &&
                                d.BranchId == x.BranchId)
                            .Select(d => d.DepartmentName)
                            .FirstOrDefault(),

                        x.RoleId,
                        RoleName = _context.Roles
                            .Where(r =>
                                r.RoleId == x.RoleId &&
                                r.CompanyId == x.CompanyId)
                            .Select(r => r.RoleName)
                            .FirstOrDefault(),
                        IsRoleMapped = _context.RoleTemplateAssignment.Any(assignment =>
assignment.CompanyId == x.CompanyId &&
assignment.EmployeeId == x.EmployeeId &&
assignment.IsActive == true &&
_context.Set<RoleTemplate>().Any(template =>
    template.CompanyId == assignment.CompanyId &&
    template.TemplateId == assignment.TemplateId &&
    template.IsActive == true)),
                        x.Designation,
                        x.ReportingToManagerCode,
                        x.Mobilenumber,
                        x.Email,
                        x.Profile,
                        x.Location,
                        x.City,
                        x.District,
                        x.State,
                        x.DateOfJoining,
                        x.IsActive,
                        x.CreatedOn,
                        x.CreatedBy
                    })
                    .ToListAsync();

                return Ok(new
                {
                    Status = true,
                    Message = employees.Count > 0
                        ? "Employee list fetched successfully."
                        : "No employees found.",
                    Data = employees
                });
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(
                    ex,
                    "Failed to fetch employees for company {CompanyId}",
                    request.CompanyId);

                return StatusCode(500, new
                {
                    Status = false,
                    Message = "Unable to fetch employee list."
                });
            }
        }

        // [HttpPost]
        // [Route("GetEmployeeList")]
        // public IActionResult GetEmployeeList([FromBody] GetEmployeeListRequest request)
        // {
        //     try
        //     {
        //         if (request == null)
        //             return Ok(new { Status = false, Message = "Invalid request" });

        //         if (request.CompanyId <= 0)
        //             return Ok(new { Status = false, Message = "CompanyId is required" });

        //         var companyExists = _context.Companys
        //             .Any(x => x.CompanyID == request.CompanyId);

        //         if (!companyExists)
        //             return Ok(new { Status = false, Message = "Company not found" });

        //         var branchIds = request.BranchList?
        //             .Where(x => x > 0)
        //             .ToList() ?? new List<int>();

        //         var deptIds = request.DeptList?
        //             .Where(x => x > 0)
        //             .ToList() ?? new List<int>();


        //         var RoleIds = request.RoleList?
        //             .Where(x => x > 0)
        //             .ToList() ?? new List<int>();

        //         var employeeBaseQuery = _context.EmployeeMasters
        //             .Where(x => x.IsActive && x.CompanyId == request.CompanyId)
        //             .AsQueryable();

        //         if (branchIds.Count > 0)
        //         {
        //             employeeBaseQuery = employeeBaseQuery
        //                 .Where(x => branchIds.Contains(x.BranchId));
        //         }

        //         if (deptIds.Count > 0)
        //         {
        //             employeeBaseQuery = employeeBaseQuery
        //                 .Where(x => deptIds.Contains(x.DepartmentId));
        //         }
        //         if (RoleIds.Count > 0)
        //         {
        //             employeeBaseQuery = employeeBaseQuery
        //                 .Where(x => RoleIds.Contains((int)x.RoleId));
        //         }
        //         var staticEncyKey = _configuration["EncryptionSettings:StaticUniqueId"];
        //         var employees = (
        //             from e in employeeBaseQuery

        //             join b in _context.Branches
        //                 on e.BranchId equals b.BranchId into branchJoin
        //             from b in branchJoin.DefaultIfEmpty()

        //             join d in _context.Departments
        //                 on e.DepartmentId equals d.DepartmentId into deptJoin
        //             from d in deptJoin.DefaultIfEmpty()

        //             join c in _context.Companys
        //                 on e.CompanyId equals c.CompanyID into companyJoin
        //             from c in companyJoin.DefaultIfEmpty()
        //             join r in _context.Rolemasters
        //on e.RoleId equals r.RoleId into roleJoin
        //             from r in roleJoin.DefaultIfEmpty()
        //             select new
        //             {
        //                 e.EmployeeId,
        //                 e.FirstName,
        //                 e.LastName,
        //                 e.IsAdmin,
        //                 EmployeeName = (e.FirstName ?? "") + " " + (e.LastName ?? ""),

        //                 e.CompanyId,
        //                 CompanyName = c != null ? c.CompanyCode : "",

        //                 e.BranchId,
        //                 BranchName = b != null ? b.BranchName : "",

        //                 e.DepartmentId,
        //                 DepartmentName = d != null ? d.DepartmentName : "",

        //                 e.Mobilenumber,
        //                 e.Email,
        //                 e.Profile,
        //                 e.RoleId,
        //                 Password = !string.IsNullOrWhiteSpace(e.Password)
        // ? Helper.Helper.DecryptAPIData(e.Password, staticEncyKey)
        // : "",
        //                 e.EmpCode,
        //                 e.City,
        //                 e.District,
        //                 e.State,
        //                 e.Location,
        //                 e.BankName,
        //                 e.Pan,
        //                 e.IFSC,
        //                 e.BankAccountNo,
        //                 e.Adhar,
        //                 e.ReportingToManagerCode,

        //                 e.DateOfJoining,
        //                 e.EmergencyNumber,

        //                 RoleName = r != null && !string.IsNullOrWhiteSpace(r.RoleName)
        //     ? r.RoleName
        //     : "Employee",



        //                 e.CreatedOn,
        //                 e.ModifiedOn,
        //                 e.CreatedBy,
        //                 e.ModifiedBy,
        //                 e.IsActive
        //             })
        //             .OrderByDescending(x => x.EmployeeId)
        //             .ToList();


        //         employees=employees.Where(a=>a.IsAdmin!=true).ToList();
        //         return Ok(new
        //         {
        //             Status = true,
        //             Message = "Employee list fetched successfully",
        //             Data = employees
        //         });
        //     }
        //     catch (Exception ex)
        //     {
        //         return Ok(new
        //         {
        //             Status = false,
        //             Message = ex.Message
        //         });
        //     }
        // }



        public class CreateEmployeeRequest
        {
            public string? FirstName { get; set; }
            public string? LastName { get; set; }

            public int CompanyId { get; set; }
            public int BranchId { get; set; }
            public int DepartmentId { get; set; }

            public string? Password { get; set; }
            public string? Mobilenumber { get; set; }
            public string? Email { get; set; }
            public string? Profile { get; set; }

            public int? CreatedBy { get; set; }
            public int? RoleId { get; set; }

            public string? City { get; set; }
            public string? District { get; set; }
            public string? State { get; set; }
            public string? Location { get; set; }

            public string? DateOfJoining { get; set; }
            public string? EmergencyNumber { get; set; }

            // New fields
            public string? EmpCode { get; set; }
            public string? Designation { get; set; }
            public string? ReportingToManagerCode { get; set; }
            public string? Pan { get; set; }
            public string? Adhar { get; set; }
            public string? BankName { get; set; }
            public string? BankAccountNo { get; set; }
            public string? IFSC { get; set; }
        }
        public class GetEmployeeListRequest
        {

            public int CompanyId { get; set; }
            public List<int>? BranchIds { get; set; }
            public List<int>? DepartmentIds { get; set; }
        }


        public class EditEmployeeRequest
        {
            public int EmployeeId { get; set; }

            public string? FirstName { get; set; }
            public string? LastName { get; set; }

            public int BranchId { get; set; }
            public int DepartmentId { get; set; }

            public string? Password { get; set; }
            public string? Mobilenumber { get; set; }
            public string? Email { get; set; }
            public string? Profile { get; set; }

            public string? City { get; set; }
            public string? District { get; set; }
            public string? State { get; set; }
            public string? Location { get; set; }

            public string? DateOfJoining { get; set; }
            public string? EmergencyNumber { get; set; }

            public int? ModifiedBy { get; set; }

            // New fields
            public string? EmpCode { get; set; }
            public string? Designation { get; set; }
            public string? ReportingToManagerCode { get; set; }
            public string? Pan { get; set; }
            public string? Adhar { get; set; }
            public string? BankName { get; set; }
            public string? BankAccountNo { get; set; }
            public string? IFSC { get; set; }
        }

        public class DeleteEmployeeRequest
        {
            public int EmployeeId { get; set; }
            public int? DeletedBy { get; set; }
            public string? DeleteType { get; set; }
            public string? DeletedReason { get; set; }
        }


       
    }
}
