﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Recruitment.Data;
using Recruitment.Model.Entity;
using System.Text.Json;

namespace Recruitment.Controllers
{
    [Route("api/AssessmentController")]
    [ApiController]
    public class AssessmentController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public AssessmentController(ApplicationDbContext dbContext, IConfiguration configuration)
        {
            this._context = dbContext;
            _configuration = configuration;
            _configuration = configuration;
        }


        [HttpPost("SaveCandidateSkillAssessment")]
        public async Task<IActionResult> SaveCandidateSkillAssessment(
         [FromBody] SaveCandidateSkillAssessmentRequest? request)
        {
            IActionResult Fail(int statusCode, string message)
            {
                return StatusCode(statusCode, new
                {
                    Status = false,
                    Message = message
                });
            }

            if (request == null)
                return Fail(400, "Invalid request.");

            if (request.CompanyId <= 0 ||
                request.CandidateId <= 0 ||
                request.JobDescriptionId <= 0 ||
                request.EmployeeId <= 0 ||
                request.SkillId <= 0 ||
                request.CandidateSkillAssessmentId < 0)
            {
                return Fail(400, "Provide valid reference IDs.");
            }

            var action = request.Action?.Trim().ToLowerInvariant() switch
            {
                null => "Save",
                "" => "Save",
                "save" => "Save",
                "addremark" => "AddRemark",
                _ => null
            };

            if (action == null)
            {
                return Fail(
                    400,
                    "This API supports Save and AddRemark. Approval/rejection is performed separately after saving.");
            }

            bool isRemarkAdded =
                action == "AddRemark" || request.IsRemarkAdded;

            if (isRemarkAdded &&
                string.IsNullOrWhiteSpace(request.Remarks))
            {
                return Fail(400, "Enter the remark to add.");
            }

            bool hasDetails =
                request.Details.HasValue &&
                request.Details.Value.ValueKind != JsonValueKind.Null &&
                request.Details.Value.ValueKind != JsonValueKind.Undefined;

            if (action == "Save" &&
                hasDetails &&
                request.Details!.Value.ValueKind != JsonValueKind.Object)
            {
                return Fail(400, "Details must be a JSON object.");
            }

            try
            {
                await using var transaction =
                    await _context.Database.BeginTransactionAsync(
                        System.Data.IsolationLevel.Serializable);

                // Acting employee.
                var employee = await _context.EmployeeMasters
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.EmployeeId == request.EmployeeId)
                    .Select(x => new
                    {
                        x.EmployeeId,
                        x.IsAdmin,
                        x.IsActive,

                        EmployeeName =
                            ((x.FirstName ?? "") + " " +
                             (x.LastName ?? "")).Trim()
                    })
                    .FirstOrDefaultAsync();

                if (employee == null)
                    return Fail(404, "Employee not found for this company.");

                if (employee.IsActive != true)
                    return Fail(403, "Employee is inactive.");

                bool isAdmin = employee.IsAdmin == true;

                var candidateExists = await _context.Candidates
                    .AsNoTracking()
                    .AnyAsync(x =>
                        x.CompanyId == request.CompanyId &&
                        x.CandidateId == request.CandidateId);

                if (!candidateExists)
                    return Fail(404, "Candidate not found for this company.");

                var job = await _context.JobDescriptions
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.JobDescriptionId == request.JobDescriptionId)
                    .Select(x => new
                    {
                        x.JobDescriptionId,
                        x.TemplateId
                    })
                    .FirstOrDefaultAsync();

                if (job == null)
                    return Fail(404, "Job description not found for this company.");

                // Resolve the candidate's application for this JD.
                var applications = await _context.CandidateApplications
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.CandidateId == request.CandidateId &&
                        x.JobDescriptionId == request.JobDescriptionId)
                    .Select(x => new
                    {
                        x.CandidateApplicationId,
                        x.IsActive
                    })
                    .Take(2)
                    .ToListAsync();

                if (applications.Count == 0)
                {
                    return Fail(
                        404,
                        "Candidate application not found for this JD.");
                }

                if (applications.Count > 1)
                {
                    return Fail(
                        409,
                        "Multiple applications exist for this candidate and JD. CandidateApplicationId is needed to identify the correct application.");
                }

                var application = applications[0];

                if (application.IsActive != true)
                    return Fail(409, "Candidate application is inactive.");

                // Skill and category.
                var skill = await _context.SkillMasters
                    .AsNoTracking()
                    .Where(x =>
                        x.SkillId == request.SkillId &&
                        x.IsActive == true)
                    .Select(x => new
                    {
                        x.SkillId,
                        x.SkillName,
                        x.CategoryId
                    })
                    .FirstOrDefaultAsync();

                if (skill == null)
                    return Fail(404, "Active skill not found.");

                var category = await _context.SkillCategories
                    .AsNoTracking()
                    .Where(x =>
                        x.CategoryId == skill.CategoryId &&
                        x.IsActive == true)
                    .Select(x => new
                    {
                        x.CategoryId,
                        x.CategoryName
                    })
                    .FirstOrDefaultAsync();

                if (category == null)
                    return Fail(404, "Active skill category not found.");

                // Non-admin assignment is determined by the JD's template.
                int? resolvedAssignmentId = null;

                if (!isAdmin)
                {
                    var assignments = await _context.RoleTemplateAssignment
                        .AsNoTracking()
                        .Where(x =>
                            x.CompanyId == request.CompanyId &&
                            x.EmployeeId == employee.EmployeeId &&
                            x.TemplateId == job.TemplateId &&
                            x.IsActive == true)
                        .Where(x =>
                            _context.Set<RoleTemplate>().Any(template =>
                                template.CompanyId == x.CompanyId &&
                                template.TemplateId == x.TemplateId &&
                                template.IsActive == true))
                        .Where(x =>
                            _context.Set<RoleTemplateAssignmentSkill>().Any(mapping =>
                                mapping.CompanyId == x.CompanyId &&
                                mapping.AssignmentId == x.AssignmentId &&
                                mapping.SkillId == request.SkillId))
                        .Select(x => x.AssignmentId)
                        .Take(2)
                        .ToListAsync();

                    if (assignments.Count == 0)
                    {
                        return Fail(
                            403,
                            "This skill is not assigned to the employee in the JD's active template.");
                    }

                    if (assignments.Count > 1)
                    {
                        return Fail(
                            409,
                            "Multiple matching assignments exist. AssignmentId is needed to identify the correct assignment.");
                    }

                    resolvedAssignmentId = assignments[0];
                }

                // Include all form versions when locating this employee's
                // existing assessment for the requested skill.
                var skillDefinitionIds = _context.SkillFormDefinitions
                    .Where(x => x.SkillId == request.SkillId)
                    .Select(x => x.SkillFormDefinitionId);

                var assessmentQuery = _context.CandidateSkillAssessments
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.JobDescriptionId == request.JobDescriptionId &&
                        x.CandidateApplicationId ==
                            application.CandidateApplicationId &&
                        x.CreatedBy == employee.EmployeeId &&
                        skillDefinitionIds.Contains(x.SkillFormDefinitionId));

                CandidateSkillAssessment? assessment;

                if (request.CandidateSkillAssessmentId > 0)
                {
                    assessment = await assessmentQuery
                        .FirstOrDefaultAsync(x =>
                            x.CandidateSkillAssessmentId ==
                                request.CandidateSkillAssessmentId);

                    if (assessment == null)
                    {
                        return Fail(
                            404,
                            "Assessment not found for this employee, candidate and skill.");
                    }
                }
                else
                {
                    var existingAssessments = await assessmentQuery
                        .Take(2)
                        .ToListAsync();

                    if (existingAssessments.Count > 1)
                    {
                        return Fail(
                            409,
                            "Multiple assessments exist. Send CandidateSkillAssessmentId.");
                    }

                    assessment = existingAssessments.FirstOrDefault();
                }

                bool isNew = assessment == null;

                if (isNew && action == "AddRemark")
                {
                    return Fail(
                        400,
                        "Save the assessment first, then add further remarks.");
                }

                if (!isNew)
                {
                    if (assessment!.IsActive != true)
                        return Fail(409, "Assessment is inactive.");

                    if (!isAdmin &&
                        assessment.AssignmentId != resolvedAssignmentId)
                    {
                        return Fail(
                            409,
                            "This assessment belongs to a different assignment.");
                    }

                    if (action == "Save" &&
                        (assessment.Status == "Approved" ||
                         assessment.Status == "Rejected"))
                    {
                        return Fail(
                            409,
                            "This assessment is completed. You can still use AddRemark.");
                    }
                }

                // Existing assessments keep their original form version.
                SkillFormDefinition? definition;

                if (isNew)
                {
                    var activeDefinitions = await _context.SkillFormDefinitions
                        .AsNoTracking()
                        .Where(x =>
                            x.SkillId == request.SkillId &&
                            x.CategoryId == skill.CategoryId &&
                            x.IsActive == true)
                        .Take(2)
                        .ToListAsync();

                    if (activeDefinitions.Count == 0)
                    {
                        return Fail(
                            400,
                            "No active form definition is configured for this skill.");
                    }

                    if (activeDefinitions.Count > 1)
                    {
                        return Fail(
                            409,
                            "Multiple active form definitions exist for this skill. Keep one active version.");
                    }

                    definition = activeDefinitions[0];
                }
                else
                {
                    definition = await _context.SkillFormDefinitions
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x =>
                            x.SkillFormDefinitionId ==
                                assessment!.SkillFormDefinitionId &&
                            x.SkillId == request.SkillId);

                    if (definition == null)
                    {
                        return Fail(
                            409,
                            "The saved assessment's form definition is unavailable.");
                    }
                }

                var now = DateTime.UtcNow;
                var previousStatus = assessment?.Status;

                if (isNew)
                {
                    assessment = new CandidateSkillAssessment
                    {
                        CompanyId = request.CompanyId,
                        JobDescriptionId = request.JobDescriptionId,
                        CandidateApplicationId =
                            application.CandidateApplicationId,
                        SkillFormDefinitionId =
                            definition.SkillFormDefinitionId,

                        // Independent admin assessment has no assignment.
                        AssignmentId = resolvedAssignmentId,

                        DetailsJson = "{}",
                        Status = "Pending",
                        IsActive = true,

                        CreatedBy = employee.EmployeeId,
                        CreatedOn = now
                    };

                    _context.CandidateSkillAssessments.Add(assessment);
                }

                if (action == "Save")
                {
                    if (hasDetails)
                    {
                        // Communication, background verification,
                        // documents/KYC and salary have additional details.
                        bool hasSkillSpecificDetails =
                            request.SkillId == 2 ||
                            request.SkillId == 6 ||
                            request.SkillId == 7 ||
                            request.SkillId == 8;

                        if (hasSkillSpecificDetails)
                        {
                            assessment!.DetailsJson =
                                request.Details!.Value.GetRawText();
                        }
                        else
                        {
                            // Current requirement: other skills use
                            // only Score and Remarks.
                            if (request.Details!.Value
                                .EnumerateObject()
                                .Any())
                            {
                                return Fail(
                                    400,
                                    "For this skill, send Details as {} and use Score and Remarks.");
                            }

                            assessment!.DetailsJson = "{}";
                        }
                    }

                    if (request.Score.HasValue)
                    {
                        assessment!.Score = request.Score.Value;
                    }

                    // Save does not approve or reject the assessment.
                    assessment!.Status = "InProgress";
                }

                if (isRemarkAdded)
                {
                    assessment!.Remarks = request.Remarks!.Trim();
                }

                if (!isNew)
                {
                    assessment!.ModifiedBy = employee.EmployeeId;
                    assessment.ModifiedOn = now;
                }

                await _context.SaveChangesAsync();

                var history = new CandidateSkillAssessmentHistory
                {
                    CandidateSkillAssessmentId =
                        assessment!.CandidateSkillAssessmentId,

                    CompanyId = assessment.CompanyId,
                    JobDescriptionId = assessment.JobDescriptionId,
                    CandidateApplicationId =
                        assessment.CandidateApplicationId,
                    SkillFormDefinitionId =
                        assessment.SkillFormDefinitionId,
                    AssignmentId = assessment.AssignmentId,

                    Action = action,
                    PreviousStatus = previousStatus,
                    NewStatus = assessment.Status,

                    DetailsJson = assessment.DetailsJson,
                    Score = assessment.Score,
                    Remarks = assessment.Remarks,
                    IsRemarkAdded = isRemarkAdded,

                    CreatedBy = employee.EmployeeId,
                    CreatedOn = now
                };

                _context.CandidateSkillAssessmentHistories.Add(history);

                await _context.SaveChangesAsync();

                var remarksCount =
                    await _context.CandidateSkillAssessmentHistories
                        .CountAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            x.CandidateSkillAssessmentId ==
                                assessment.CandidateSkillAssessmentId &&
                            x.IsRemarkAdded);

                // Return an object rather than an escaped JSON string.
                using var detailsDocument =
                    JsonDocument.Parse(assessment.DetailsJson);

                var responseDetails = detailsDocument.RootElement.Clone();

                await transaction.CommitAsync();

                return Ok(new
                {
                    Status = true,

                    Message = action == "AddRemark"
                        ? "Remark added successfully."
                        : "Assessment saved successfully.",

                    Data = new
                    {
                        assessment.CandidateSkillAssessmentId,
                        assessment.CompanyId,
                        request.CandidateId,
                        assessment.JobDescriptionId,
                        assessment.CandidateApplicationId,

                        skill.SkillId,
                        skill.SkillName,
                        category.CategoryId,
                        category.CategoryName,

                        assessment.SkillFormDefinitionId,
                        FormVersion = definition.Version,
                        assessment.AssignmentId,

                        Details = responseDetails,
                        assessment.Score,
                        assessment.Remarks,
                        AssessmentStatus = assessment.Status,

                        RemarksCount = remarksCount,

                        assessment.CreatedBy,
                        CreatedByName = employee.EmployeeName,
                        assessment.CreatedOn,

                        assessment.ModifiedBy,
                        ModifiedByName = assessment.ModifiedBy.HasValue
                            ? employee.EmployeeName
                            : null,
                        assessment.ModifiedOn
                    }
                });
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(
                    ex,
                    "Failed to save skill assessment for CompanyId {CompanyId}, CandidateId {CandidateId}, JobDescriptionId {JobDescriptionId}, EmployeeId {EmployeeId}.",
                    request.CompanyId,
                    request.CandidateId,
                    request.JobDescriptionId,
                    request.EmployeeId);

                return StatusCode(500, new
                {
                    Status = false,
                    Message = "Unable to save skill assessment."
                });
            }
        }







        [HttpPost("ApproveRejectSkillAssessment")]
        public async Task<IActionResult> ApproveRejectSkillAssessment(
    [FromBody] UpdateSkillAssessmentStatusRequest? request)
        {
            IActionResult Fail(int code, string message)
            {
                return StatusCode(code, new
                {
                    Status = false,
                    Message = message
                });
            }

            if (request == null ||
                request.CompanyId <= 0 ||
                request.CandidateSkillAssessmentId <= 0 ||
                request.EmployeeId <= 0)
            {
                return Fail(
                    400,
                    "Valid CompanyId, CandidateSkillAssessmentId and EmployeeId are required.");
            }

            var action = request.Action?.Trim().ToLowerInvariant() switch
            {
                "approve" => "Approve",
                "reject" => "Reject",
                _ => null
            };

            if (action == null)
            {
                return Fail(400, "Action must be Approve or Reject.");
            }

            try
            {
                await using var transaction =
                    await _context.Database.BeginTransactionAsync(
                        System.Data.IsolationLevel.Serializable);

                var employee = await _context.EmployeeMasters
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.CompanyId == request.CompanyId &&
                        x.EmployeeId == request.EmployeeId);

                if (employee == null)
                    return Fail(404, "Employee not found for this company.");

                if (employee.IsActive != true)
                    return Fail(403, "Employee is inactive.");

                bool isAdmin = employee.IsAdmin == true;

                var assessment = await _context.CandidateSkillAssessments
                    .FirstOrDefaultAsync(x =>
                        x.CompanyId == request.CompanyId &&
                        x.CandidateSkillAssessmentId ==
                            request.CandidateSkillAssessmentId);

                if (assessment == null)
                    return Fail(404, "Skill assessment not found.");

                if (assessment.IsActive != true)
                    return Fail(409, "Skill assessment is inactive.");

                // Current rule: each employee acts on their own assessment.
                if (assessment.CreatedBy != employee.EmployeeId)
                {
                    return Fail(
                        403,
                        "You can only approve or reject your own assessment.");
                }

                if (assessment.Status == "Approved" ||
                    assessment.Status == "Rejected")
                {
                    return Fail(
                        409,
                        $"This assessment is already {assessment.Status.ToLowerInvariant()}.");
                }

                // Require a saved assessment before making a decision.
                if (assessment.Status != "InProgress")
                {
                    return Fail(
                        409,
                        "Save the assessment before approving or rejecting it.");
                }

                var application = await _context.CandidateApplications
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.CompanyId == request.CompanyId &&
                        x.CandidateApplicationId ==
                            assessment.CandidateApplicationId &&
                        x.JobDescriptionId ==
                            assessment.JobDescriptionId);

                if (application == null)
                {
                    return Fail(
                        404,
                        "Candidate application not found for this assessment.");
                }

                if (application.IsActive != true)
                    return Fail(409, "Candidate application is inactive.");

                var definition = await _context.SkillFormDefinitions
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.SkillFormDefinitionId ==
                            assessment.SkillFormDefinitionId);

                if (definition == null)
                    return Fail(404, "Assessment form definition not found.");

                // An existing assessment may use an older inactive form version.
                var skill = await _context.SkillMasters
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.SkillId == definition.SkillId &&
                        x.CategoryId == definition.CategoryId &&
                        x.IsActive == true);

                if (skill == null)
                    return Fail(409, "The assessment skill is unavailable.");

                var category = await _context.SkillCategories
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.CategoryId == skill.CategoryId &&
                        x.IsActive == true);

                if (category == null)
                    return Fail(409, "The skill category is unavailable.");

                if (!isAdmin)
                {
                    if (!assessment.AssignmentId.HasValue)
                    {
                        return Fail(
                            403,
                            "No role assignment is linked to this assessment.");
                    }

                    var assignment = await _context.RoleTemplateAssignment
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            x.AssignmentId == assessment.AssignmentId.Value &&
                            x.EmployeeId == employee.EmployeeId &&
                            x.IsActive == true);

                    if (assignment == null)
                    {
                        return Fail(
                            403,
                            "Active role assignment not found for this employee.");
                    }

                    var job = await _context.JobDescriptions
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            x.JobDescriptionId == assessment.JobDescriptionId);

                    if (job == null ||
                        job.TemplateId != assignment.TemplateId)
                    {
                        return Fail(
                            403,
                            "The assignment does not match the JD's template.");
                    }

                    var templateIsActive = await _context.Set<RoleTemplate>()
                        .AsNoTracking()
                        .AnyAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            x.TemplateId == assignment.TemplateId &&
                            x.IsActive == true);

                    if (!templateIsActive)
                        return Fail(403, "The assignment template is inactive.");

                    var skillIsAssigned =
                        await _context.Set<RoleTemplateAssignmentSkill>()
                            .AsNoTracking()
                            .AnyAsync(x =>
                                x.CompanyId == request.CompanyId &&
                                x.AssignmentId == assignment.AssignmentId &&
                                x.SkillId == skill.SkillId);

                    if (!skillIsAssigned)
                    {
                        return Fail(
                            403,
                            "This skill is no longer assigned to the employee.");
                    }

                    if (action == "Approve" &&
                        assignment.CanApprove != true)
                    {
                        return Fail(403, "Approve permission is not available.");
                    }

                    if (action == "Reject" &&
                        assignment.CanReject != true)
                    {
                        return Fail(403, "Reject permission is not available.");
                    }
                }

                var now = DateTime.UtcNow;
                var previousStatus = assessment.Status;

                bool isRemarkAdded =
                    !string.IsNullOrWhiteSpace(request.Remarks);

                assessment.Status = action == "Approve"
                    ? "Approved"
                    : "Rejected";

                if (isRemarkAdded)
                {
                    assessment.Remarks = request.Remarks!.Trim();
                }

                assessment.ModifiedBy = employee.EmployeeId;
                assessment.ModifiedOn = now;

                // Answers, score and creation fields remain unchanged.
                var history = new CandidateSkillAssessmentHistory
                {
                    CandidateSkillAssessmentId =
                        assessment.CandidateSkillAssessmentId,

                    CompanyId = assessment.CompanyId,
                    JobDescriptionId = assessment.JobDescriptionId,
                    CandidateApplicationId =
                        assessment.CandidateApplicationId,
                    SkillFormDefinitionId =
                        assessment.SkillFormDefinitionId,
                    AssignmentId = assessment.AssignmentId,

                    Action = action,
                    PreviousStatus = previousStatus,
                    NewStatus = assessment.Status,

                    DetailsJson = assessment.DetailsJson,
                    Score = assessment.Score,
                    Remarks = assessment.Remarks,
                    IsRemarkAdded = isRemarkAdded,

                    CreatedBy = employee.EmployeeId,
                    CreatedOn = now
                };

                _context.CandidateSkillAssessmentHistories.Add(history);

                await _context.SaveChangesAsync();

                var remarksCount =
                    await _context.CandidateSkillAssessmentHistories
                        .CountAsync(x =>
                            x.CompanyId == request.CompanyId &&
                            x.CandidateSkillAssessmentId ==
                                assessment.CandidateSkillAssessmentId &&
                            x.IsRemarkAdded);

                await transaction.CommitAsync();

                var employeeName =
                    ((employee.FirstName ?? "") + " " +
                     (employee.LastName ?? "")).Trim();

                return Ok(new
                {
                    Status = true,
                    Message = action == "Approve"
                        ? "Skill assessment approved successfully."
                        : "Skill assessment rejected successfully.",

                    Data = new
                    {
                        assessment.CandidateSkillAssessmentId,
                        assessment.CompanyId,
                        application.CandidateId,
                        assessment.CandidateApplicationId,
                        assessment.JobDescriptionId,

                        skill.SkillId,
                        skill.SkillName,
                        category.CategoryId,
                        category.CategoryName,

                        AssessmentStatus = assessment.Status,
                        assessment.Score,
                        assessment.Remarks,
                        RemarksCount = remarksCount,

                        assessment.CreatedBy,
                        CreatedByName = employeeName,
                        assessment.CreatedOn,

                        assessment.ModifiedBy,
                        ModifiedByName = employeeName,
                        assessment.ModifiedOn,

                        CanApprove = false,
                        CanReject = false
                    }
                });
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(
                    ex,
                    "Failed to update assessment status for CompanyId {CompanyId}, AssessmentId {AssessmentId}, EmployeeId {EmployeeId}.",
                    request.CompanyId,
                    request.CandidateSkillAssessmentId,
                    request.EmployeeId);

                return StatusCode(500, new
                {
                    Status = false,
                    Message = "Unable to update skill assessment status."
                });
            }
        }

        [HttpPost("GetCandidateSkillAssessmentList")]
        public async Task<IActionResult> GetCandidateSkillAssessmentList(
      [FromBody] GetCandidateSkillAssessmentListRequest? request)
        {
            if (request == null ||
                request.CompanyId <= 0 ||
                request.User <= 0)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Valid CompanyId and User are required."
                });
            }

            if (request.CandidateId < 0 ||
                request.JobDescriptionId < 0 ||
                request.SkillCategoryId < 0)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Filter IDs cannot be negative."
                });
            }

            try
            {
                var currentUser = await _context.EmployeeMasters
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.EmployeeId == request.User)
                    .Select(x => new
                    {
                        x.EmployeeId,
                        x.IsAdmin,
                        x.IsActive
                    })
                    .FirstOrDefaultAsync();

                if (currentUser == null)
                {
                    return NotFound(new
                    {
                        Status = false,
                        Message = "User not found for this company."
                    });
                }

                if (currentUser.IsActive != true)
                {
                    return StatusCode(403, new
                    {
                        Status = false,
                        Message = "User is inactive."
                    });
                }

                bool isAdmin = currentUser.IsAdmin == true;

                // Company-specific categories and skills.
                var skillsQuery =
                    from skill in _context.Set<CompanySkillMaster>()
                        .AsNoTracking()

                    join category in _context.Set<CompanySkillMapping>()
                        .AsNoTracking()
                        on new
                        {
                            skill.CompanyId,
                            skill.SkillMappingId
                        }
                        equals new
                        {
                            category.CompanyId,
                            category.SkillMappingId
                        }

                    where skill.CompanyId == request.CompanyId
                          && skill.IsActive == true
                          && category.IsActive == true

                    select new
                    {
                        SkillCategoryId = category.SkillMappingId,
                        SkillCategoryName = category.CategoryName,

                        SkillMasterId = skill.CompanySkillMasterId,
                        skill.SkillName,
                        skill.IsDisable
                    };

                if (request.SkillCategoryId > 0)
                {
                    skillsQuery = skillsQuery.Where(x =>
                        x.SkillCategoryId == request.SkillCategoryId);
                }

                // IsDisable is intentionally not used as a filter.
                var companySkills = await skillsQuery
                    .OrderBy(x => x.SkillCategoryId)
                    .ThenBy(x => x.SkillMasterId)
                    .ToListAsync();

                var applicationsQuery = _context.CandidateApplications
                    .AsNoTracking()
                    .Where(x => x.CompanyId == request.CompanyId);

                if (request.CandidateId > 0)
                {
                    applicationsQuery = applicationsQuery.Where(x =>
                        x.CandidateId == request.CandidateId);
                }

                if (request.JobDescriptionId > 0)
                {
                    applicationsQuery = applicationsQuery.Where(x =>
                        x.JobDescriptionId == request.JobDescriptionId);
                }

                var applications = await (
                    from application in applicationsQuery

                    join candidate in _context.Candidates.AsNoTracking()
                        on new
                        {
                            application.CompanyId,
                            application.CandidateId
                        }
                        equals new
                        {
                            candidate.CompanyId,
                            candidate.CandidateId
                        }

                    join job in _context.JobDescriptions.AsNoTracking()
                        on new
                        {
                            application.CompanyId,
                            application.JobDescriptionId
                        }
                        equals new
                        {
                            job.CompanyId,
                            job.JobDescriptionId
                        }

                    select new
                    {
                        application.CandidateApplicationId,
                        application.JobDescriptionId,

                        candidate.CandidateId,
                        candidate.FirstName,
                        candidate.MiddleName,
                        candidate.LastName,

                        JobName = job.JobTitle,
                        TemplateId = (int?)job.TemplateId
                    }
                )
                .OrderByDescending(x => x.CandidateApplicationId)
                .ToListAsync();

                if (companySkills.Count == 0 || applications.Count == 0)
                {
                    return Ok(new
                    {
                        Status = true,
                        Message = companySkills.Count == 0
                            ? "No active company skills found."
                            : "No candidate applications found.",
                        IsAdmin = isAdmin,
                        TotalCount = 0,
                        Data = Array.Empty<object>()
                    });
                }

                var applicationIds = applications
                    .Select(x => x.CandidateApplicationId)
                    .Distinct()
                    .ToArray();

                var templateIds = applications
                    .Where(x => x.TemplateId.HasValue)
                    .Select(x => x.TemplateId!.Value)
                    .Distinct()
                    .ToArray();

                var skillIds = companySkills
                    .Select(x => x.SkillMasterId)
                    .Distinct()
                    .ToArray();

                // Used only to restrict non-admin visibility.
                var assignedSkillsQuery =
                    from assignment in _context.RoleTemplateAssignment
                        .AsNoTracking()

                    join template in _context.RoleTemplates.AsNoTracking()
                        on new
                        {
                            assignment.CompanyId,
                            assignment.TemplateId
                        }
                        equals new
                        {
                            template.CompanyId,
                            template.TemplateId
                        }

                    join mapping in _context.RoleTemplateAssignmentSkills
                        .AsNoTracking()
                        on new
                        {
                            assignment.CompanyId,
                            assignment.AssignmentId
                        }
                        equals new
                        {
                            mapping.CompanyId,
                            mapping.AssignmentId
                        }

                    where assignment.CompanyId == request.CompanyId
                          && assignment.EmployeeId == request.User
                          && assignment.IsActive == true
                          && template.IsActive == true
                          && templateIds.Contains(assignment.TemplateId)
                          && skillIds.Contains(mapping.SkillId)

                    select new
                    {
                        assignment.TemplateId,
                        assignment.AssignmentId,
                        assignment.EmployeeId,
                        assignment.RoleId,
                        assignment.HierarchyLevel,
                        SkillMasterId = mapping.SkillId
                    };

                // Admin does not require any assignment.
                var assignedSkills = await assignedSkillsQuery
                    .Where(x => !isAdmin)
                    .Distinct()
                    .ToListAsync();

                var assessmentsQuery = _context.CandidateSkillAssessments
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        applicationIds.Contains(x.CandidateApplicationId));

                if (!isAdmin)
                {
                    assessmentsQuery = assessmentsQuery.Where(x =>
                        x.CreatedBy == request.User);
                }

                // Includes admin assessments with AssignmentId = null.
                var savedAssessments = await (
                    from assessment in assessmentsQuery

                    join definition in _context.SkillFormDefinitions
                        .AsNoTracking()
                        on assessment.SkillFormDefinitionId
                        equals definition.SkillFormDefinitionId

                    where skillIds.Contains(definition.SkillId)

                    select new
                    {
                        Assessment = assessment,
                        SkillMasterId = definition.SkillId,
                        SkillCategoryId = definition.CategoryId,
                        FormVersion = definition.Version
                    }
                ).ToListAsync();

                var assessmentLookup = savedAssessments.ToLookup(x => (
                    x.Assessment.CandidateApplicationId,
                    x.Assessment.JobDescriptionId,
                    x.SkillCategoryId,
                    x.SkillMasterId
                ));

                var assessmentIds = savedAssessments
                    .Select(x => x.Assessment.CandidateSkillAssessmentId)
                    .Distinct()
                    .ToArray();

                var histories = await _context.CandidateSkillAssessmentHistories
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        assessmentIds.Contains(x.CandidateSkillAssessmentId))
                    .OrderByDescending(x => x.CreatedOn)
                    .ThenByDescending(x =>
                        x.CandidateSkillAssessmentHistoryId)
                    .ToListAsync();

                var historyLookup = histories.ToLookup(x =>
                    x.CandidateSkillAssessmentId);

                var employeeIds = savedAssessments
                    .SelectMany(x => new int?[]
                    {
                x.Assessment.CreatedBy,
                x.Assessment.ModifiedBy
                    })
                    .Concat(histories.Select(x => (int?)x.CreatedBy))
                    .Concat(new int?[] { request.User })
                    .Where(x => x.HasValue)
                    .Select(x => x!.Value)
                    .Distinct()
                    .ToArray();

                var employeeNames = await _context.EmployeeMasters
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        employeeIds.Contains(x.EmployeeId))
                    .Select(x => new
                    {
                        x.EmployeeId,
                        EmployeeName =
                            ((x.FirstName ?? "") + " " +
                             (x.LastName ?? "")).Trim()
                    })
                    .ToDictionaryAsync(
                        x => x.EmployeeId,
                        x => x.EmployeeName);

                // Load assignment metadata for saved assessments and role rows.
                var assignmentIds = savedAssessments
                    .Where(x => x.Assessment.AssignmentId.HasValue)
                    .Select(x => x.Assessment.AssignmentId!.Value)
                    .Concat(assignedSkills.Select(x => x.AssignmentId))
                    .Distinct()
                    .ToArray();

                var assignmentDetails = await _context.RoleTemplateAssignment
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        assignmentIds.Contains(x.AssignmentId))
                    .Select(x => new
                    {
                        x.AssignmentId,
                        x.RoleId,
                        x.HierarchyLevel
                    })
                    .ToDictionaryAsync(x => x.AssignmentId);

                var roleIds = assignmentDetails.Values
                    .Select(x => x.RoleId)
                    .Distinct()
                    .ToArray();

                var roleNames = await _context.Roles
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        roleIds.Contains(x.RoleId))
                    .ToDictionaryAsync(x => x.RoleId, x => x.RoleName);

                string? GetEmployeeName(int? employeeId)
                {
                    return employeeId.HasValue &&
                           employeeNames.TryGetValue(
                               employeeId.Value, out var name)
                        ? name
                        : null;
                }

                static JsonElement ReadDetails(string? json)
                {
                    using var document = JsonDocument.Parse(
                        string.IsNullOrWhiteSpace(json) ? "{}" : json);

                    return document.RootElement.Clone();
                }

                var data = new System.Collections.Generic.List<object>();

                foreach (var application in applications)
                {
                    foreach (var skill in companySkills)
                    {
                        var matchingAssignments = assignedSkills
                            .Where(x =>
                                application.TemplateId == x.TemplateId &&
                                x.SkillMasterId == skill.SkillMasterId)
                            .ToList();

                        // Only non-admin users need a matching role assignment.
                        if (!isAdmin && matchingAssignments.Count == 0)
                        {
                            continue;
                        }

                        var matchingAssessments = assessmentLookup[(
                            application.CandidateApplicationId,
                            application.JobDescriptionId,
                            skill.SkillCategoryId,
                            skill.SkillMasterId
                        )].ToList();

                        if (!isAdmin)
                        {
                            var allowedAssignmentIds = matchingAssignments
                                .Select(x => x.AssignmentId)
                                .ToHashSet();

                            matchingAssessments = matchingAssessments
                                .Where(x =>
                                    x.Assessment.AssignmentId.HasValue &&
                                    allowedAssignmentIds.Contains(
                                        x.Assessment.AssignmentId.Value))
                                .ToList();
                        }

                        // Admin: all saved assessments for this company skill.
                        // If none exist, return one unsaved Pending row.
                        // Non-admin: one row per assignment, including unsaved rows.
                        var scopes = isAdmin
                            ? new int?[] { null }
                            : matchingAssignments
                                .Select(x => (int?)x.AssignmentId)
                                .Distinct()
                                .ToArray();

                        foreach (var scopeAssignmentId in scopes)
                        {
                            var scopeAssessments = matchingAssessments
                                .Where(x =>
                                    isAdmin ||
                                    x.Assessment.AssignmentId == scopeAssignmentId)
                                .ToList();

                            foreach (var saved in scopeAssessments.DefaultIfEmpty())
                            {
                                var assessment = saved?.Assessment;

                                int? assignmentId =
                                    assessment?.AssignmentId ?? scopeAssignmentId;

                                int? roleId = null;
                                int? hierarchyLevel = null;
                                string? roleName = null;

                                if (assignmentId.HasValue &&
                                    assignmentDetails.TryGetValue(
                                        assignmentId.Value, out var assignment))
                                {
                                    roleId = assignment.RoleId;
                                    hierarchyLevel = assignment.HierarchyLevel;

                                    roleNames.TryGetValue(
                                        assignment.RoleId, out roleName);
                                }

                                // Unsaved admin rows have no assessment owner.
                                int? employeeId = assessment != null
                                    ? assessment.CreatedBy
                                    : isAdmin
                                        ? (int?)null
                                        : request.User;

                                var assessmentHistory = historyLookup[
                                    assessment?.CandidateSkillAssessmentId ?? 0]
                                    .ToList();

                                var remarkHistory = assessmentHistory
                                    .Where(x => x.IsRemarkAdded)
                                    .Select(x => new
                                    {
                                        HistoryId =
                                            x.CandidateSkillAssessmentHistoryId,
                                        x.Action,
                                        x.Remarks,
                                        x.CreatedBy,
                                        CreatedByName =
                                            GetEmployeeName(x.CreatedBy),
                                        x.CreatedOn
                                    })
                                    .ToList();

                                data.Add(new
                                {
                                    CandidateSkillAssessmentId =
                                        assessment?.CandidateSkillAssessmentId,

                                    request.CompanyId,
                                    application.CandidateId,

                                    CandidateName = string.Join(
                                        " ",
                                        new[]
                                        {
                                    application.FirstName,
                                    application.MiddleName,
                                    application.LastName
                                        }.Where(x =>
                                            !string.IsNullOrWhiteSpace(x))),

                                    application.CandidateApplicationId,
                                    application.JobDescriptionId,
                                    application.JobName,
                                    application.TemplateId,

                                    skill.SkillCategoryId,
                                    skill.SkillCategoryName,

                                    // Existing response name retained.
                                    SkillId = skill.SkillMasterId,
                                    skill.SkillMasterId,
                                    skill.SkillName,
                                    skill.IsDisable,

                                    AssignmentId = assignmentId,
                                    RoleId = roleId,
                                    RoleName = roleName,
                                    HierarchyLevel = hierarchyLevel,

                                    EmployeeId = employeeId,
                                    EmployeeName = GetEmployeeName(employeeId),

                                    SkillFormDefinitionId =
                                        assessment?.SkillFormDefinitionId,
                                    FormVersion = saved?.FormVersion,

                                    IsAssessmentSaved = assessment != null,

                                    Details = ReadDetails(
                                        assessment?.DetailsJson),

                                    Score = assessment?.Score,
                                    Remarks = assessment?.Remarks,
                                    AssessmentStatus =
                                        assessment?.Status ?? "Pending",

                                    // Null means an assessment has not been saved.
                                    IsActive = assessment?.IsActive,

                                    CreatedBy = assessment?.CreatedBy,
                                    CreatedByName =
                                        GetEmployeeName(assessment?.CreatedBy),
                                    CreatedOn = assessment?.CreatedOn,

                                    ModifiedBy = assessment?.ModifiedBy,
                                    ModifiedByName =
                                        GetEmployeeName(assessment?.ModifiedBy),
                                    ModifiedOn = assessment?.ModifiedOn,

                                    RemarksCount = remarkHistory.Count,
                                    RemarkHistory = remarkHistory,

                                    History = assessmentHistory.Select(x => new
                                    {
                                        HistoryId =
                                            x.CandidateSkillAssessmentHistoryId,
                                        x.Action,
                                        x.PreviousStatus,
                                        x.NewStatus,
                                        x.SkillFormDefinitionId,

                                        Details = ReadDetails(x.DetailsJson),

                                        x.Score,
                                        x.Remarks,
                                        x.IsRemarkAdded,

                                        x.CreatedBy,
                                        CreatedByName =
                                            GetEmployeeName(x.CreatedBy),
                                        x.CreatedOn
                                    }).ToList()
                                });
                            }
                        }
                    }
                }

                return Ok(new
                {
                    Status = true,
                    Message = data.Count > 0
                        ? "Skill assessments fetched successfully."
                        : "No assigned skills found for this user and job.",
                    IsAdmin = isAdmin,
                    TotalCount = data.Count,
                    Data = data
                });
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(
                    ex,
                    "Failed to fetch skill assessments for CompanyId {CompanyId}, User {UserId}.",
                    request.CompanyId,
                    request.User);

                return StatusCode(500, new
                {
                    Status = false,
                    Message = "Unable to fetch skill assessments."
                });
            }
        }























        public class GetCandidateSkillAssessmentListRequest
        {
            public int CompanyId { get; set; }

            public int CandidateId { get; set; }

            public int JobDescriptionId { get; set; }

            public int SkillCategoryId { get; set; }

            // EmployeeMasters.EmployeeId
            public int User { get; set; }
        }

        public class UpdateSkillAssessmentStatusRequest
        {
            public int CompanyId { get; set; }

            public int CandidateSkillAssessmentId { get; set; }

            public int EmployeeId { get; set; }

            // Approve or Reject
            public string? Action { get; set; }

            public string? Remarks { get; set; }
        }


        public class SaveCandidateSkillAssessmentRequest
        {
            public int CandidateSkillAssessmentId { get; set; }

            public int CompanyId { get; set; }

            public int CandidateId { get; set; }

            public int JobDescriptionId { get; set; }

            public int EmployeeId { get; set; }

            public int SkillId { get; set; }

            // Save or AddRemark.
            public string? Action { get; set; } = "Save";

            // Omitted/null preserves existing answers.
            // When supplied, replaces the complete answers object.
            public JsonElement? Details { get; set; }

            // Omitted/null preserves the existing score.
            public decimal? Score { get; set; }

            public string? Remarks { get; set; }

            // True when deliberately adding a new top-level remark.
            public bool IsRemarkAdded { get; set; }
        }
    }
}
