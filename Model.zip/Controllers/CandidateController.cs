﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Recruitment.Data;
using Recruitment.Model.Entity;
using System.ComponentModel.DataAnnotations;

namespace Recruitment.Controllers
{
    [Route("api/CandidateController")]
    [ApiController]
    public class CandidateController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public CandidateController(ApplicationDbContext dbContext, IConfiguration configuration)
        {
            this._context = dbContext;
            _configuration = configuration;
            _configuration = configuration;
        }









        
        [HttpPost("SaveCandidates")]
        public async Task<IActionResult> SaveCandidates(
    [FromBody] SaveCandidatesRequest? request)
        {
            IActionResult Fail(int statusCode, string message)
            {
                return StatusCode(statusCode, new
                {
                    Status = false,
                    Message = message
                });
            }

            // 0 means not selected for these optional references.
            int? OptionalId(int? value)
            {
                return value == 0 ? null : value;
            }

            string NormalizeCurrency(string? value)
            {
                if (string.IsNullOrWhiteSpace(value))
                    return "INR";

                var currency = value.Trim();

                // INR(₹) or INR (₹) becomes INR.
                var bracketIndex = currency.IndexOf('(');

                if (bracketIndex >= 0)
                {
                    currency = currency.Substring(0, bracketIndex).Trim();
                }

                return string.IsNullOrWhiteSpace(currency)
                    ? "INR"
                    : currency.ToUpperInvariant();
            }

            if (request == null ||
                request.Candidates == null ||
                request.Candidates.Count == 0 ||
                request.Candidates.Any(x => x == null))
            {
                return Fail(400, "Please provide candidate details.");
            }

            if (request.JobDescriptionId <= 0)
            {
                return Fail(400, "Valid JobDescriptionId is required.");
            }

            var submittedMobileNumbers = new HashSet<string>();

            foreach (var row in request.Candidates)
            {
                if (string.IsNullOrWhiteSpace(row.MobileNumber))
                {
                    return Fail(400, "Candidate mobile number is required.");
                }

                row.MobileNumber = row.MobileNumber.Trim();

                if (!submittedMobileNumbers.Add(row.MobileNumber))
                {
                    return Fail(
                        409,
                        $"Mobile number {row.MobileNumber} appears more than once for this JD.");
                }
            }

            try
            {
                await using var transaction =
                    await _context.Database.BeginTransactionAsync(
                        System.Data.IsolationLevel.Serializable);

                var job = await _context.JobDescriptions
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        x.JobDescriptionId == request.JobDescriptionId)
                    .Select(x => new
                    {
                        x.JobDescriptionId,
                        x.JobTitle
                    })
                    .FirstOrDefaultAsync();

                if (job == null)
                {
                    return Fail(
                        404,
                        "Job description not found for this company.");
                }

                var savedApplicationIds = new List<int>();

                foreach (var row in request.Candidates)
                {
                    var now = DateTime.UtcNow;

                    bool isNewCandidate = row.CandidateId == 0;
                    bool isNewApplication = row.CandidateApplicationId == 0;

                    Candidate candidate;

                    if (isNewCandidate)
                    {
                        if (!isNewApplication)
                        {
                            return Fail(
                                404,
                                "Candidate application not found for the supplied candidate.");
                        }

                        candidate = new Candidate
                        {
                            CompanyId = request.CompanyId,
                            CreatedOn = now,
                            CreatedBy = request.UserId
                        };
                    }
                    else
                    {
                        var existingCandidate = await _context.Candidates
                            .FirstOrDefaultAsync(x =>
                                x.CompanyId == request.CompanyId &&
                                x.CandidateId == row.CandidateId);

                        if (existingCandidate == null)
                        {
                            return Fail(
                                404,
                                $"Candidate {row.CandidateId} not found for this company.");
                        }

                        candidate = existingCandidate;
                    }

                    CandidateApplication application;

                    if (isNewApplication)
                    {
                        application = new CandidateApplication
                        {
                            CompanyId = request.CompanyId,
                            JobDescriptionId = request.JobDescriptionId,
                            AppliedPosition = job.JobTitle,
                            Stage = "Screening",
                            Status = "Pending",
                            AppliedOn = now,
                            CreatedOn = now,
                            CreatedBy = request.UserId
                        };
                    }
                    else
                    {
                        var existingApplication =
                            await _context.CandidateApplications
                                .FirstOrDefaultAsync(x =>
                                    x.CompanyId == request.CompanyId &&
                                    x.CandidateApplicationId ==
                                        row.CandidateApplicationId &&
                                    x.CandidateId == row.CandidateId &&
                                    x.JobDescriptionId ==
                                        request.JobDescriptionId);

                        if (existingApplication == null)
                        {
                            return Fail(
                                404,
                                $"Application {row.CandidateApplicationId} not found for this candidate and JD.");
                        }

                        application = existingApplication;
                    }

                    // Same company + JD + mobile is not allowed.
                    // Excludes the application currently being edited.
                    // Includes inactive applications.
                    bool duplicateMobile = await (
                        from existingApplication in
                            _context.CandidateApplications
                        join existingCandidate in _context.Candidates
                            on new
                            {
                                existingApplication.CompanyId,
                                existingApplication.CandidateId
                            }
                            equals new
                            {
                                existingCandidate.CompanyId,
                                existingCandidate.CandidateId
                            }
                        where
                            existingApplication.CompanyId ==
                                request.CompanyId &&
                            existingApplication.JobDescriptionId ==
                                request.JobDescriptionId &&
                            existingApplication.CandidateApplicationId !=
                                row.CandidateApplicationId &&
                            existingCandidate.MobileNumber.Trim() ==
                                row.MobileNumber
                        select existingApplication.CandidateApplicationId
                    ).AnyAsync();

                    if (duplicateMobile)
                    {
                        return Fail(
                            409,
                            $"Mobile number {row.MobileNumber} is already registered for this JD.");
                    }

                    // Changing a candidate's mobile affects their other applications.
                    if (!isNewCandidate &&
                        candidate.MobileNumber != row.MobileNumber)
                    {
                        var candidateJobIds = _context.CandidateApplications
                            .Where(x =>
                                x.CompanyId == request.CompanyId &&
                                x.CandidateId == candidate.CandidateId)
                            .Select(x => x.JobDescriptionId);

                        bool duplicateOnAnotherJob = await (
                            from otherApplication in
                                _context.CandidateApplications
                            join otherCandidate in _context.Candidates
                                on new
                                {
                                    otherApplication.CompanyId,
                                    otherApplication.CandidateId
                                }
                                equals new
                                {
                                    otherCandidate.CompanyId,
                                    otherCandidate.CandidateId
                                }
                            where
                                otherApplication.CompanyId ==
                                    request.CompanyId &&
                                otherCandidate.CandidateId !=
                                    candidate.CandidateId &&
                                candidateJobIds.Contains(
                                    otherApplication.JobDescriptionId) &&
                                otherCandidate.MobileNumber.Trim() ==
                                    row.MobileNumber
                            select otherApplication.CandidateApplicationId
                        ).AnyAsync();

                        if (duplicateOnAnotherJob)
                        {
                            return Fail(
                                409,
                                "This mobile number is already registered for another JD belonging to this candidate.");
                        }
                    }

                    // Personal information.
                    candidate.FirstName =
                        row.FirstName?.Trim() ?? string.Empty;

                    candidate.MiddleName = row.MiddleName?.Trim();
                    candidate.LastName = row.LastName?.Trim();

                    candidate.Email = row.Email?.Trim();
                    candidate.AlternateEmail = row.AlternateEmail?.Trim();

                    candidate.MobileNumber = row.MobileNumber!;

                    candidate.AlternateMobileNumber =
                        row.AlternateMobileNumber?.Trim();

                    candidate.Gender = row.Gender?.Trim();
                    candidate.DateOfBirth = row.DateOfBirth;

                    candidate.CurrentAddress = row.CurrentAddress?.Trim();
                    candidate.PermanentAddress = row.PermanentAddress?.Trim();
                    candidate.CurrentCity = row.CurrentCity?.Trim();
                    candidate.State = row.State?.Trim();
                    candidate.Country = row.Country?.Trim();
                    candidate.Pincode = row.Pincode?.Trim();

                    // Professional information.
                    candidate.CurrentCompany = row.CurrentCompany?.Trim();

                    candidate.CurrentDesignation =
                        row.CurrentDesignation?.Trim();

                    candidate.EmploymentStatus =
                        row.EmploymentStatus?.Trim();

                    candidate.TotalExperienceYears =
                        row.TotalExperienceYears;

                    candidate.RelevantExperienceYears =
                        row.RelevantExperienceYears;

                    candidate.NoticePeriodDays = row.NoticePeriodDays;

                    candidate.PreviousCompany = row.PreviousCompany?.Trim();
                    candidate.Industry = row.Industry?.Trim();
                    candidate.FunctionalArea = row.FunctionalArea?.Trim();

                    candidate.HighestQualification =
                        row.HighestQualification?.Trim();

                    candidate.Specialization = row.Specialization?.Trim();
                    candidate.University = row.University?.Trim();
                    candidate.PassingYear = row.PassingYear;

                    candidate.IsActive = row.IsActive;

                    // Resume is stored in Candidate, as requested.
                    // Null/blank preserves the existing resume on edit.
                    if (!string.IsNullOrWhiteSpace(row.ResumePath))
                    {
                        candidate.ResumePath = row.ResumePath.Trim();
                    }

                    if (isNewCandidate)
                    {
                        _context.Candidates.Add(candidate);
                    }
                    else
                    {
                        candidate.ModifiedOn = now;
                        candidate.ModifiedBy = request.UserId;
                    }

                    // Generate CandidateId for a new candidate.
                    await _context.SaveChangesAsync();

                    // Application details.
                    application.CandidateId = candidate.CandidateId;

                    // Requires nullable entity properties and database columns.
                    application.BranchId = OptionalId(row.BranchId);
                    application.DepartmentId = OptionalId(row.DepartmentId);

                    // INR(₹) -> INR; null/blank -> INR.
                    application.Currency = NormalizeCurrency(row.Currency);

                    application.CurrentCTC = row.CurrentCTC;
                    application.CurrentFixedCTC = row.CurrentFixedCTC;
                    application.CurrentVariableCTC = row.CurrentVariableCTC;

                    application.ExpectedCTC = row.ExpectedCTC;
                    application.ExpectedFixedCTC = row.ExpectedFixedCTC;
                    application.ExpectedVariableCTC = row.ExpectedVariableCTC;

                    application.CurrentMonthlySalary =
                        row.CurrentMonthlySalary;

                    application.ExpectedMonthlySalary =
                        row.ExpectedMonthlySalary;

                    application.OfferedCTC = row.OfferedCTC;
                    application.IsNegotiable = row.IsNegotiable;

                    application.Source = row.Source?.Trim();
                    application.ReferredBy = row.ReferredBy?.Trim();

                    application.RecruiterEmployeeId =
                        OptionalId(row.RecruiterEmployeeId);

                    application.HiringManagerEmployeeId =
                        OptionalId(row.HiringManagerEmployeeId);

                    application.RecruitmentCityId =
                        OptionalId(row.RecruitmentCityId);

                    application.Cadre = row.Cadre?.Trim();

                    application.InterviewRequired = row.InterviewRequired;

                    application.PreferredInterviewDate =
                        row.PreferredInterviewDate;

                    application.PreferredLocation =
                        row.PreferredLocation?.Trim();

                    application.WillingToRelocate =
                        row.WillingToRelocate;

                    application.CandidateAvailability =
                        row.CandidateAvailability?.Trim();

                    application.Remarks = row.Remarks?.Trim();

                    // Your pasted code did not save VerificationRemarks.
                    // Enable only if the entity property and DB column exist:
                    // application.VerificationRemarks =
                    //     row.VerificationRemarks?.Trim();

                    application.IsActive = row.IsActive;

                    // Existing Stage and Status remain unchanged on edit.
                    if (isNewApplication)
                    {
                        _context.CandidateApplications.Add(application);
                    }
                    else
                    {
                        application.ModifiedOn = now;
                        application.ModifiedBy = request.UserId;
                    }

                    // Generate CandidateApplicationId for a new application.
                    await _context.SaveChangesAsync();

                    // Save document references.
                    // Null/empty list leaves existing documents unchanged.
                    if (row.Documents != null)
                    {
                        foreach (var documentRequest in row.Documents)
                        {
                            CandidateDocument document;

                            if (documentRequest.CandidateDocumentId == 0)
                            {
                                document = new CandidateDocument
                                {
                                    CompanyId = request.CompanyId,
                                    CandidateApplicationId =
                                        application.CandidateApplicationId,
                                    CreatedOn = now,
                                    CreatedBy = request.UserId
                                };

                                _context.CandidateDocuments.Add(document);
                            }
                            else
                            {
                                var existingDocument =
                                    await _context.CandidateDocuments
                                        .FirstOrDefaultAsync(x =>
                                            x.CompanyId == request.CompanyId &&
                                            x.CandidateApplicationId ==
                                                application.CandidateApplicationId &&
                                            x.CandidateDocumentId ==
                                                documentRequest.CandidateDocumentId);

                                if (existingDocument == null)
                                {
                                    return Fail(
                                        404,
                                        $"Document {documentRequest.CandidateDocumentId} not found for this candidate application.");
                                }

                                document = existingDocument;
                                document.ModifiedOn = now;
                                document.ModifiedBy = request.UserId;
                            }

                            document.DocumentType =
                                documentRequest.DocumentType?.Trim()
                                ?? string.Empty;

                            document.OriginalFileName =
                                documentRequest.OriginalFileName?.Trim()
                                ?? string.Empty;

                            document.StorageKey =
                                documentRequest.FilePath?.Trim()
                                ?? string.Empty;

                            document.ContentType =
                                documentRequest.ContentType?.Trim();

                            document.FileSizeBytes =
                                documentRequest.FileSizeBytes ?? 0;
                        }
                    }

                    await _context.SaveChangesAsync();

                    savedApplicationIds.Add(
                        application.CandidateApplicationId);
                }

                var savedApplications = await (
                    from application in
                        _context.CandidateApplications.AsNoTracking()
                    join candidate in _context.Candidates.AsNoTracking()
                        on new
                        {
                            application.CompanyId,
                            application.CandidateId
                        }
                        equals new
                        {
                            candidate.CompanyId,
                            candidate.CandidateId
                        }
                    where
                        application.CompanyId == request.CompanyId &&
                        savedApplicationIds.Contains(
                            application.CandidateApplicationId)
                    orderby application.CandidateApplicationId descending
                    select new
                    {
                        candidate.CandidateId,

                        CandidateName =
                            ((candidate.FirstName ?? "") + " " +
                             (candidate.MiddleName ?? "") + " " +
                             (candidate.LastName ?? "")).Trim(),

                        candidate.MobileNumber,
                        candidate.ResumePath,

                        application.CandidateApplicationId,
                        application.CompanyId,

                        CompanyName = _context.Companys
                            .Where(x =>
                                x.CompanyID == application.CompanyId)
                            .Select(x => x.CompanyName)
                            .FirstOrDefault(),

                        application.JobDescriptionId,
                        JobTitle = job.JobTitle,
                        application.AppliedPosition,

                        application.BranchId,

                        BranchName = _context.Branches
                            .Where(x =>
                                x.CompanyId == application.CompanyId &&
                                x.BranchId == application.BranchId)
                            .Select(x => x.BranchName)
                            .FirstOrDefault(),

                        application.DepartmentId,

                        DepartmentName = _context.Departments
                            .Where(x =>
                                x.CompanyId == application.CompanyId &&
                                x.DepartmentId == application.DepartmentId)
                            .Select(x => x.DepartmentName)
                            .FirstOrDefault(),

                        application.Stage,
                        application.Status,
                        application.IsActive,

                        application.CreatedOn,
                        application.CreatedBy,

                        CreatedByName = _context.EmployeeMasters
                            .Where(x =>
                                x.CompanyId == application.CompanyId &&
                                x.EmployeeId == application.CreatedBy)
                            .Select(x =>
                                ((x.FirstName ?? "") + " " +
                                 (x.LastName ?? "")).Trim())
                            .FirstOrDefault(),

                        application.ModifiedOn,
                        application.ModifiedBy,

                        ModifiedByName = _context.EmployeeMasters
                            .Where(x =>
                                x.CompanyId == application.CompanyId &&
                                x.EmployeeId == application.ModifiedBy)
                            .Select(x =>
                                ((x.FirstName ?? "") + " " +
                                 (x.LastName ?? "")).Trim())
                            .FirstOrDefault()
                    }
                ).ToListAsync();

                var savedDocuments = await _context.CandidateDocuments
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        savedApplicationIds.Contains(
                            x.CandidateApplicationId))
                    .OrderBy(x => x.CandidateDocumentId)
                    .Select(x => new
                    {
                        x.CandidateDocumentId,
                        x.CandidateApplicationId,
                        x.DocumentType,
                        x.OriginalFileName,
                        FilePath = x.StorageKey,
                        x.ContentType,
                        x.FileSizeBytes,
                        x.IsActive
                    })
                    .ToListAsync();

                var documentsByApplication = savedDocuments
                    .ToLookup(x => x.CandidateApplicationId);

                var data = savedApplications.Select(x => new
                {
                    x.CandidateId,
                    x.CandidateName,
                    x.MobileNumber,
                    x.ResumePath,
                    x.CandidateApplicationId,
                    x.CompanyId,
                    x.CompanyName,
                    x.JobDescriptionId,
                    x.JobTitle,
                    x.AppliedPosition,
                    x.BranchId,
                    x.BranchName,
                    x.DepartmentId,
                    x.DepartmentName,
                    x.Stage,
                    x.Status,
                    x.IsActive,
                    x.CreatedOn,
                    x.CreatedBy,
                    x.CreatedByName,
                    x.ModifiedOn,
                    x.ModifiedBy,
                    x.ModifiedByName,

                    Documents = documentsByApplication[
                        x.CandidateApplicationId].ToList()
                }).ToList();

                await transaction.CommitAsync();

                return Ok(new
                {
                    Status = true,
                    Message = "Candidates saved successfully.",
                    Data = data
                });
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(
                    ex,
                    "Failed to save candidates for CompanyId {CompanyId}, JobDescriptionId {JobDescriptionId}.",
                    request.CompanyId,
                    request.JobDescriptionId);

                return StatusCode(500, new
                {
                    Status = false,
                    Message = "Unable to save candidates."
                });
            }
        }



        [HttpPost("GetCandidateList")]
        public async Task<IActionResult> GetCandidateList(
        [FromBody] GetCandidateListRequest? request)
        {
            if (request == null || request.CompanyId <= 0)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Valid CompanyId is required."
                });
            }

            // null, [], or any list containing 0 means all.
            static int[] GetFilterIds(List<int>? values)
            {
                if (values == null ||
                    values.Count == 0 ||
                    values.Contains(0))
                {
                    return Array.Empty<int>();
                }

                return values.Distinct().ToArray();
            }

            try
            {
                var branchIds = GetFilterIds(request.BranchIds);
                var departmentIds = GetFilterIds(request.DepartmentIds);

                var query =
                    from application in _context.CandidateApplications.AsNoTracking()
                    join candidate in _context.Candidates.AsNoTracking()
                        on new
                        {
                            application.CompanyId,
                            application.CandidateId
                        }
                        equals new
                        {
                            candidate.CompanyId,
                            candidate.CandidateId
                        }
                    where application.CompanyId == request.CompanyId
                    select new
                    {
                        Application = application,
                        Candidate = candidate
                    };

                if (branchIds.Length > 0)
                {
                    query = query.Where(x =>
                        x.Application.BranchId.HasValue &&
                        branchIds.Contains(x.Application.BranchId.Value));
                }

                if (departmentIds.Length > 0)
                {
                    query = query.Where(x =>
                        x.Application.DepartmentId.HasValue &&
                        departmentIds.Contains(x.Application.DepartmentId.Value));
                }

                var rows = await query
                    .OrderByDescending(x =>
                        x.Application.CandidateApplicationId)
                    .ToListAsync();

                if (rows.Count == 0)
                {
                    return Ok(new
                    {
                        Status = true,
                        Message = "No candidates found.",
                        TotalCount = 0,
                        Data = Array.Empty<object>()
                    });
                }

                var resultApplicationIds = rows
                    .Select(x => x.Application.CandidateApplicationId)
                    .Distinct()
                    .ToArray();

                var resultJobIds = rows
                    .Select(x => x.Application.JobDescriptionId)
                    .Distinct()
                    .ToArray();

                var resultBranchIds = rows
                    .Where(x => x.Application.BranchId.HasValue)
                    .Select(x => x.Application.BranchId!.Value)
                    .Distinct()
                    .ToArray();

                var resultDepartmentIds = rows
                    .Where(x => x.Application.DepartmentId.HasValue)
                    .Select(x => x.Application.DepartmentId!.Value)
                    .Distinct()
                    .ToArray();

                var resultCityIds = rows
                    .Where(x => x.Application.RecruitmentCityId.HasValue)
                    .Select(x => x.Application.RecruitmentCityId!.Value)
                    .Distinct()
                    .ToArray();

                var companyName = await _context.Companys
                    .AsNoTracking()
                    .Where(x => x.CompanyID == request.CompanyId)
                    .Select(x => x.CompanyName)
                    .FirstOrDefaultAsync();

                var jobs = await _context.JobDescriptions
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        resultJobIds.Contains(x.JobDescriptionId))
                    .Select(x => new
                    {
                        x.JobDescriptionId,
                        x.JobTitle
                    })
                    .ToDictionaryAsync(
                        x => x.JobDescriptionId,
                        x => x.JobTitle);

                var branches = await _context.Branches
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        resultBranchIds.Contains(x.BranchId))
                    .Select(x => new
                    {
                        x.BranchId,
                        x.BranchName
                    })
                    .ToDictionaryAsync(
                        x => x.BranchId,
                        x => x.BranchName);

                var departments = await _context.Departments
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        resultDepartmentIds.Contains(x.DepartmentId))
                    .Select(x => new
                    {
                        x.DepartmentId,
                        x.DepartmentName
                    })
                    .ToDictionaryAsync(
                        x => x.DepartmentId,
                        x => x.DepartmentName);

                var cities = await _context.Cities
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        resultCityIds.Contains(x.CityId))
                    .Select(x => new
                    {
                        x.CityId,
                        x.CityName
                    })
                    .ToDictionaryAsync(
                        x => x.CityId,
                        x => x.CityName);

                var documents = await _context.CandidateDocuments
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        resultApplicationIds.Contains(
                            x.CandidateApplicationId))
                    .OrderByDescending(x => x.CandidateDocumentId)
                    .ToListAsync();

                // Includes application, candidate and document audit users.
                var employeeIds = rows
                    .SelectMany(x => new int?[]
                    {
                x.Application.RecruiterEmployeeId,
                x.Application.HiringManagerEmployeeId,
                x.Application.CreatedBy,
                x.Application.ModifiedBy,
                x.Candidate.CreatedBy,
                x.Candidate.ModifiedBy
                    })
                    .Concat(documents.SelectMany(x => new int?[]
                    {
                x.CreatedBy,
                x.ModifiedBy
                    }))
                    .Where(x => x.HasValue)
                    .Select(x => x!.Value)
                    .Distinct()
                    .ToArray();

                var employeeNames = await _context.EmployeeMasters
                    .AsNoTracking()
                    .Where(x =>
                        x.CompanyId == request.CompanyId &&
                        employeeIds.Contains(x.EmployeeId))
                    .Select(x => new
                    {
                        x.EmployeeId,

                        EmployeeName =
                            ((x.FirstName ?? "") + " " +
                             (x.LastName ?? "")).Trim()
                    })
                    .ToDictionaryAsync(
                        x => x.EmployeeId,
                        x => x.EmployeeName);

                string? GetEmployeeName(int? employeeId)
                {
                    if (employeeId.HasValue &&
                        employeeNames.TryGetValue(
                            employeeId.Value, out var name))
                    {
                        return name;
                    }

                    return null;
                }

                var documentsByApplication = documents.ToLookup(
                    x => x.CandidateApplicationId);

                var data = rows.Select(row =>
                {
                    var candidate = row.Candidate;
                    var application = row.Application;

                    jobs.TryGetValue(
                        application.JobDescriptionId,
                        out var jobTitle);

                    string? branchName = null;

                    if (application.BranchId.HasValue)
                    {
                        branches.TryGetValue(
                            application.BranchId.Value,
                            out branchName);
                    }

                    string? departmentName = null;

                    if (application.DepartmentId.HasValue)
                    {
                        departments.TryGetValue(
                            application.DepartmentId.Value,
                            out departmentName);
                    }

                    string? recruitmentCityName = null;

                    if (application.RecruitmentCityId.HasValue)
                    {
                        cities.TryGetValue(
                            application.RecruitmentCityId.Value,
                            out recruitmentCityName);
                    }

                    return new
                    {
                        application.CompanyId,
                        CompanyName = companyName,

                        candidate.CandidateId,
                        application.CandidateApplicationId,

                        application.JobDescriptionId,
                        JobTitle = jobTitle,
                        application.AppliedPosition,

                        application.BranchId,
                        BranchName = branchName,

                        application.DepartmentId,
                        DepartmentName = departmentName,

                        // Personal information
                        candidate.FirstName,
                        candidate.MiddleName,
                        candidate.LastName,

                        CandidateName = string.Join(
                            " ",
                            new[]
                            {
                        candidate.FirstName,
                        candidate.MiddleName,
                        candidate.LastName
                            }.Where(x => !string.IsNullOrWhiteSpace(x))),

                        candidate.Email,
                        candidate.AlternateEmail,
                        candidate.MobileNumber,
                        candidate.AlternateMobileNumber,
                        candidate.Gender,
                        candidate.DateOfBirth,

                        candidate.CurrentAddress,
                        candidate.PermanentAddress,
                        candidate.CurrentCity,
                        candidate.State,
                        candidate.Country,
                        candidate.Pincode,

                        // Professional information
                        candidate.CurrentCompany,
                        candidate.CurrentDesignation,
                        candidate.EmploymentStatus,
                        candidate.TotalExperienceYears,
                        candidate.RelevantExperienceYears,
                        candidate.NoticePeriodDays,
                        candidate.PreviousCompany,
                        candidate.Industry,
                        candidate.FunctionalArea,
                        candidate.HighestQualification,
                        candidate.Specialization,
                        candidate.University,
                        candidate.PassingYear,
                        candidate.ResumePath,

                        // Compensation
                        application.Currency,
                        application.CurrentCTC,
                        application.CurrentFixedCTC,
                        application.CurrentVariableCTC,
                        application.ExpectedCTC,
                        application.ExpectedFixedCTC,
                        application.ExpectedVariableCTC,
                        application.CurrentMonthlySalary,
                        application.ExpectedMonthlySalary,
                        application.OfferedCTC,
                        application.IsNegotiable,

                        // Recruitment information
                        application.Source,
                        application.ReferredBy,

                        application.RecruiterEmployeeId,
                        RecruiterEmployeeName = GetEmployeeName(
                            application.RecruiterEmployeeId),

                        application.HiringManagerEmployeeId,
                        HiringManagerEmployeeName = GetEmployeeName(
                            application.HiringManagerEmployeeId),

                        application.RecruitmentCityId,
                        RecruitmentCityName = recruitmentCityName,

                        application.Cadre,
                        application.InterviewRequired,
                        application.PreferredInterviewDate,
                        application.PreferredLocation,
                        application.WillingToRelocate,
                        application.CandidateAvailability,
                        application.Remarks,

                        application.Stage,
                        ApplicationStatus = application.Status,
                        application.AppliedOn,
                        application.IsActive,

                        CandidateIsActive = candidate.IsActive,

                        // Application audit
                        application.CreatedOn,
                        application.CreatedBy,
                        CreatedByName = GetEmployeeName(application.CreatedBy),

                        application.ModifiedOn,
                        application.ModifiedBy,
                        ModifiedByName = GetEmployeeName(application.ModifiedBy),

                        // Candidate master audit
                        CandidateCreatedOn = candidate.CreatedOn,
                        CandidateCreatedBy = candidate.CreatedBy,
                        CandidateCreatedByName = GetEmployeeName(
                            candidate.CreatedBy),

                        CandidateModifiedOn = candidate.ModifiedOn,
                        CandidateModifiedBy = candidate.ModifiedBy,
                        CandidateModifiedByName = GetEmployeeName(
                            candidate.ModifiedBy),

                        // Includes active and inactive document references.
                        Documents = documentsByApplication[
                            application.CandidateApplicationId]
                            .Select(document => new
                            {
                                document.CandidateDocumentId,
                                document.CandidateApplicationId,
                                document.DocumentType,
                                document.OriginalFileName,

                                FilePath = document.StorageKey,

                                document.ContentType,
                                document.FileSizeBytes,
                                document.IsActive,

                                document.CreatedOn,
                                document.CreatedBy,

                                CreatedByName = GetEmployeeName(
                                    document.CreatedBy),

                                document.ModifiedOn,
                                document.ModifiedBy,

                                ModifiedByName = GetEmployeeName(
                                    document.ModifiedBy)
                            })
                            .ToList()
                    };
                }).ToList();

                return Ok(new
                {
                    Status = true,
                    Message = "Candidate list fetched successfully.",
                    TotalCount = data.Count,
                    Data = data
                });
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(
                    ex,
                    "Failed to fetch candidates for CompanyId {CompanyId}.",
                    request.CompanyId);

                return StatusCode(500, new
                {
                    Status = false,
                    Message = "Unable to fetch candidate list."
                });
            }
        }

        public class GetCandidateListRequest
        {
            public int CompanyId { get; set; }

            public List<int>? BranchIds { get; set; }

            public List<int>? DepartmentIds { get; set; }
        }


        public class SaveCandidatesRequest
    {
        public int CompanyId { get; set; }

        public int JobDescriptionId { get; set; }

        public int? UserId { get; set; }

        public List<SaveCandidateRequest> Candidates { get; set; } = new();
    }

    public class SaveCandidateRequest
    {
        public int CandidateId { get; set; }

        public int CandidateApplicationId { get; set; }

        // Job placement
        public int BranchId { get; set; }

        public int DepartmentId { get; set; }

        // Personal information
        public string? FirstName { get; set; }
        public string? ResumePath { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }

        public string? Email { get; set; }
        public string? AlternateEmail { get; set; }

        public string? MobileNumber { get; set; }
        public string? AlternateMobileNumber { get; set; }

        public string? Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }

        public string? CurrentAddress { get; set; }
        public string? PermanentAddress { get; set; }

        public string? CurrentCity { get; set; }
        public string? State { get; set; }
        public string? Country { get; set; }
        public string? Pincode { get; set; }

        // Professional information
        public string? CurrentCompany { get; set; }
        public string? CurrentDesignation { get; set; }
        public string? EmploymentStatus { get; set; }

        public decimal? TotalExperienceYears { get; set; }
        public decimal? RelevantExperienceYears { get; set; }

        public int? NoticePeriodDays { get; set; }

        public string? PreviousCompany { get; set; }
        public string? Industry { get; set; }
        public string? FunctionalArea { get; set; }

        public string? HighestQualification { get; set; }
        public string? Specialization { get; set; }
        public string? University { get; set; }
        public int? PassingYear { get; set; }

        // Compensation: annual amounts, not LPA
        public string? Currency { get; set; } = "INR";

        public decimal? CurrentCTC { get; set; }
        public decimal? CurrentFixedCTC { get; set; }
        public decimal? CurrentVariableCTC { get; set; }

        public decimal? ExpectedCTC { get; set; }
        public decimal? ExpectedFixedCTC { get; set; }
        public decimal? ExpectedVariableCTC { get; set; }

        public decimal? CurrentMonthlySalary { get; set; }
        public decimal? ExpectedMonthlySalary { get; set; }

        public decimal? OfferedCTC { get; set; }
        public bool? IsNegotiable { get; set; }

        // Recruitment information
        public string? Source { get; set; }
        public string? ReferredBy { get; set; }

        public int? RecruiterEmployeeId { get; set; }
        public int? HiringManagerEmployeeId { get; set; }

        public int? RecruitmentCityId { get; set; }
        public string? Cadre { get; set; }

        public bool? InterviewRequired { get; set; }
        public DateTime? PreferredInterviewDate { get; set; }

        public string? PreferredLocation { get; set; }
        public bool? WillingToRelocate { get; set; }

        public string? CandidateAvailability { get; set; }

        public string? Remarks { get; set; }
        public string? VerificationRemarks { get; set; }

        public bool IsActive { get; set; } = true;
         
            public List<SaveCandidateDocumentRequest>? Documents { get; set; }
    }

    public class SaveCandidateDocumentRequest
    {
        public int CandidateDocumentId { get; set; }

        public string? DocumentType { get; set; }

        public string? OriginalFileName { get; set; }

        // Example: /Content/CandidateDocuments/ydhsbjkns.jpg
        public string? FilePath { get; set; }

        public string? ContentType { get; set; }

        public long? FileSizeBytes { get; set; }
    }
}
}
