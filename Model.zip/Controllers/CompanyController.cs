﻿
using MailChimp.Net.Core;
using Microsoft.AspNetCore.Mvc;
using Recruitment.Data;
using Recruitment.Model.Entity;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;

namespace IMS.Controllers
{
    [Route("api/CompanyController")]
    [ApiController]
    public class CompanyController : Controller
    {
        private readonly ApplicationDbContext dbContext;
        private readonly IConfiguration _configuration;
        public CompanyController(ApplicationDbContext dbContext, IConfiguration configuration)
        {
            this.dbContext = dbContext;
            _configuration = configuration;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("AddcompanyDetails")]
        public IActionResult AddcompanyDetails(Companyreg dto)
        {
            var mobileExists = dbContext.Companys
                .Any(x => x.Mobile == dto.Mobile);

            if (mobileExists)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Mobile number already exists."
                });
            }

            var emailExists = dbContext.Companys
                .Any(x => x.Email == dto.Email);

            if (emailExists)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = "Email already exists."
                });
            }

            var vehicleTypeIds = dto.VehicleTypeIds?
         .Where(x => x > 0)
         .Distinct()
         .ToList() ?? new List<int>();

            var brandIds = dto.BrandIds?
                .Where(x => x > 0)
                .Distinct()
                .ToList() ?? new List<int>();


            var validBrands = new List<dynamic>();



            var CompanyDetails = new Company()
            {
                CompanyCode = dto.CompanyCode,
                CompanyName = dto.CompanyName,
                Email = dto.Email,
                Mobile = dto.Mobile,
                Website = dto.Website,
                GSTNo = dto.GSTNo,
                PANNo = dto.PANNo,
                Address = dto.Address,
                City = dto.City,
                State = dto.State,
                Pincode = dto.Pincode,
                Logo = dto.Logo,
                CompanyType = dto.CompanyType,
                IsActive = dto.IsActive,
                CreatedOn = dto.CreatedOn,
                Password = dto.Password,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                EpId=dto.EpId

            };

            dbContext.Companys.Add(CompanyDetails);
            dbContext.SaveChanges();

          
            var staticEncyKey = _configuration["EncryptionSettings:StaticUniqueId"];
            var encryptedPassword = Helper.Helper.EncryptAPIData(
                dto.Password,
                staticEncyKey
            );

            var adminEmployee = new Employee
            {
                FirstName = dto.FirstName ?? "Admin",
                LastName = dto.LastName ,
                CompanyId = CompanyDetails.CompanyID,
                BranchId = 0, // Set to 0 as per requirement
                DepartmentId = 0, // Set to 0 as per requirement
                Password = encryptedPassword,
                Mobilenumber = dto.Mobile,
                Email = dto.Email,
                Profile = null,
                RoleId = null,
                City = dto.City,
                District = null,
                State = dto.State,
                Location = null,
                DateOfJoining = DateTime.Now,
                EmergencyNumber = null,
                CreatedBy = CompanyDetails.CompanyID,
                CreatedOn = DateTime.Now,
                IsActive = true,
                IsAdmin = true, // Set IsAdmin = true

                // Optional fields
                EmpCode = $"ADMIN_{CompanyDetails.CompanyID}",
                Designation = "Company Admin",
                ReportingToManagerCode = null,
                Pan = null,
                Adhar = null,
                BankName = null,
                BankAccountNo = null,
                IFSC = null
            };

            dbContext.EmployeeMasters.Add(adminEmployee);
            dbContext.SaveChanges();


            return Ok(new
            {
                Status = true,
                Message = "Company added successfully.",
                Data = CompanyDetails
            });
        }

        [HttpPost]
        [Route("UpdateCompanyDetails")]
        public IActionResult UpdateCompanyDetails(Companyreg dto)
        {
            try
            {
                if (dto == null || dto.companyID <= 0)
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "CompanyID is required"
                    });
                }

                // =====================================================
                // CHECK IF COMPANY EXISTS
                // =====================================================

                var existingCompany = dbContext.Companys
                    .FirstOrDefault(x => x.CompanyID == dto.companyID);

                if (existingCompany == null)
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "Company not found"
                    });
                }

                // =====================================================
                // CHECK DUPLICATE MOBILE (EXCLUDING CURRENT COMPANY)
                // =====================================================

                var mobileExists = dbContext.Companys
                    .Any(x => x.Mobile == dto.Mobile && x.CompanyID != dto.companyID);

                if (mobileExists)
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "Mobile number already exists in another company."
                    });
                }

                // =====================================================
                // CHECK DUPLICATE EMAIL (EXCLUDING CURRENT COMPANY)
                // =====================================================

                var emailExists = dbContext.Companys
                    .Any(x => x.Email == dto.Email && x.CompanyID != dto.companyID);

                if (emailExists)
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "Email already exists in another company."
                    });
                }

                // =====================================================
                // UPDATE COMPANY DETAILS
                // =====================================================

                existingCompany.CompanyCode = dto.CompanyCode;
                existingCompany.CompanyName = dto.CompanyName;
                existingCompany.Email = dto.Email;
                existingCompany.Mobile = dto.Mobile;
                existingCompany.Website = dto.Website;
                existingCompany.GSTNo = dto.GSTNo;
                existingCompany.PANNo = dto.PANNo;
                existingCompany.Address = dto.Address;
                existingCompany.City = dto.City;
                existingCompany.State = dto.State;
                existingCompany.Pincode = dto.Pincode;
                existingCompany.Logo = dto.Logo;
                existingCompany.CompanyType = dto.CompanyType;
                existingCompany.IsActive = dto.IsActive;
                existingCompany.FirstName = dto.FirstName;
                existingCompany.LastName = dto.LastName;
                existingCompany.EpId = dto.EpId;

                // Update password only if provided
                if (!string.IsNullOrWhiteSpace(dto.Password))
                {
                    var staticEncyKey = _configuration["EncryptionSettings:StaticUniqueId"];
                    existingCompany.Password = Helper.Helper.EncryptAPIData(dto.Password, staticEncyKey);
                }

                // Update timestamp
           

                dbContext.SaveChanges();

                // =====================================================
                // UPDATE VEHICLE TYPES (Replace existing)
                // =====================================================

               

            
             
                dbContext.SaveChanges();

                // =====================================================
                // UPDATE ADMIN EMPLOYEE
                // =====================================================

                var adminEmployee = dbContext.EmployeeMasters
                    .FirstOrDefault(x => x.CompanyId == dto.companyID && x.IsAdmin == true);

                if (adminEmployee != null)
                {
                    adminEmployee.FirstName = dto.FirstName ?? adminEmployee.FirstName;
                    adminEmployee.LastName = dto.LastName ?? adminEmployee.LastName;
                    adminEmployee.Mobilenumber = dto.Mobile ?? adminEmployee.Mobilenumber;
                    adminEmployee.Email = dto.Email ?? adminEmployee.Email;
                    adminEmployee.City = dto.City ?? adminEmployee.City;
                    adminEmployee.State = dto.State ?? adminEmployee.State;
                    adminEmployee.ModifiedOn = DateTime.Now;
                    adminEmployee.ModifiedBy = dto.companyID;

                    // Update password only if provided
                    if (!string.IsNullOrWhiteSpace(dto.Password))
                    {
                        var staticEncyKey = _configuration["EncryptionSettings:StaticUniqueId"];
                        adminEmployee.Password = Helper.Helper.EncryptAPIData(dto.Password, staticEncyKey);
                    }

                    dbContext.SaveChanges();
                }

                return Ok(new
                {
                    Status = true,
                    Message = "Company updated successfully.",
                    Data = new
                    {
                        existingCompany.CompanyID,
                        existingCompany.CompanyCode,
                        existingCompany.CompanyName,
                        existingCompany.Email,
                        existingCompany.Mobile,
                        existingCompany.Website,
                        existingCompany.GSTNo,
                        existingCompany.PANNo,
                        existingCompany.Address,
                        existingCompany.City,
                        existingCompany.State,
                        existingCompany.Pincode,
                        existingCompany.CompanyType,
                        existingCompany.IsActive,
                        existingCompany.Logo,
                        existingCompany.FirstName,
                        existingCompany.LastName,
                        existingCompany.EpId
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    Status = false,
                    Message = ex.InnerException?.Message ?? ex.Message
                });
            }
        }


        [HttpGet]
        [Route("GetCompanywiseDetails")]
        public IActionResult GetCompanywiseDetails(int id)
        {
            var baseUrl = $"{Request.Scheme}://{Request.Host}/IMS/";

            var companyDetails = dbContext.Companys
                .Where(x => x.CompanyID == id)
                .Select(x => new
                {
                    x.CompanyID,
                    x.CompanyCode,
                    x.CompanyName,
                    x.FirstName,
                    x.LastName,
                    x.Email,
                    x.Mobile,
                    x.Website,
                    x.GSTNo,
                    x.PANNo,
                    x.Address,
                    x.City,
                    x.State,
                    x.Pincode,
                    x.CompanyType,
                    x.IsActive,
                    x.CreatedOn,
                    x.EpId,
                    Logo = string.IsNullOrWhiteSpace(x.Logo),
                    //Logo = string.IsNullOrWhiteSpace(x.Logo)
                    //    ? null
                    //    : x.Logo.StartsWith("http")
                    //        ? x.Logo
                    //        : baseUrl + x.Logo,

                
                })
                .FirstOrDefault();

            if (companyDetails == null)
            {
                return NotFound(new
                {
                    Status = false,
                    Message = "Company not found"
                });
            }



            return Ok(new
            {
                Status = true,
                Message = "Company details fetched successfully",
                Data = companyDetails
            });
        }

        public class LoginRequest
        {
            public string? Mobile { get; set; }

            public string? Password { get; set; }
        }
        [HttpPost]
        [Route("Login")]
        public IActionResult Login([FromBody] LoginRequest dto)
        {
            try
            {
                // =====================================================
                // REQUEST VALIDATION
                // =====================================================

                if (dto == null)
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "Invalid request."
                    });
                }

                if (string.IsNullOrWhiteSpace(dto.Mobile))
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "Mobile Number is required."
                    });
                }

                if (string.IsNullOrWhiteSpace(dto.Password))
                {
                    return BadRequest(new
                    {
                        Status = false,
                        Message = "Password is required."
                    });
                }


                // =====================================================
                // GET ENCRYPTION KEY
                // =====================================================

                var staticEncyKey =
                    _configuration["EncryptionSettings:StaticUniqueId"];

                if (string.IsNullOrWhiteSpace(staticEncyKey))
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Encryption key is not configured."
                    });
                }


                // =====================================================
                // ENCRYPT REQUEST PASSWORD
                //
                // Same logic used while saving employee password
                // =====================================================

                var encryptedPassword =
                    Helper.Helper.EncryptAPIData(
                        dto.Password,
                        staticEncyKey
                    );
                bool isRoleLogin = dto.Mobile
    .Trim()
    .ToLower()
    .Contains("@");

                // =====================================================
                // STEP 1: LOGIN FROM EMPLOYEE MASTER ONLY
                //
                // Mobile + Encrypted Password
                // =====================================================

                //var employee = dbContext.EmployeeMasters
                //    .FirstOrDefault(x =>
                //        x.Mobilenumber == dto.Mobile &&
                //        x.Password == encryptedPassword &&
                //        x.IsActive);

                var loginValue = dto.Mobile.Trim().ToLower();

                var employee = isRoleLogin
                    ? dbContext.EmployeeMasters
                        .AsEnumerable()
                        .FirstOrDefault(x =>
                            x.IsActive &&
                            !string.IsNullOrWhiteSpace(x.RoleMail) &&
                            x.RoleMail.Trim().ToLower() == loginValue &&
                            x.RolePW == encryptedPassword)

                    : dbContext.EmployeeMasters
                        .FirstOrDefault(x =>
                            x.Mobilenumber == dto.Mobile &&
                            x.Password == encryptedPassword &&
                            x.IsActive);

                if (employee == null)
                {
                    return Unauthorized(new
                    {
                        Status = false,
                        Message = isRoleLogin
                            ? "Invalid Role Email or Password."
                            : "Invalid Mobile Number or Password."
                    });
                }


                // =====================================================
                // STEP 2: GET COMPANY NAME ONLY
                //
                // Company table is NOT used for login validation
                // =====================================================

                var companyName = dbContext.Companys
                    .Where(x =>
                        x.CompanyID == employee.CompanyId)
                    .Select(x => x.CompanyName)
                    .FirstOrDefault() ?? "";


                // =====================================================
                // DEFAULT VALUES
                // =====================================================

                bool isAdmin =
                    employee.IsAdmin ?? false;

                string roleName =
                    "Employee";

                string? userName =
                    null;

                string? password =
                    null;


                // =====================================================
                // DECRYPT NORMAL EMPLOYEE PASSWORD
                // =====================================================

                string? normalEmployeePassword =
                    null;

                if (!string.IsNullOrWhiteSpace(
                    employee.Password))
                {
                    normalEmployeePassword =
                        Helper.Helper.DecryptAPIData(
                            employee.Password,
                            staticEncyKey
                        );
                }


                // =====================================================
                // STEP 3: ISADMIN = TRUE
                //
                // Directly RoleName = Admin
                //
                // Username = Mobile
                // Password = Normal Employee Password
                // =====================================================

                if (isAdmin)
                {
                    roleName = "Admin";

                    userName =
                        employee.Mobilenumber;

                    password =
                        normalEmployeePassword;
                }
                else
                {
                    // =================================================
                    // STEP 4: GET ROLE NAME FROM ROLE MASTER
                    // =================================================



                    // =================================================
                    // STEP 5: ROLE = EMPLOYEE
                    //
                    // Username = Mobile
                    // Password = Normal Employee Password
                    // =================================================

                    if (roleName.Equals(
                        "Employee",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        userName =
                            employee.Mobilenumber;

                        password =
                            normalEmployeePassword;
                    }


                    // =================================================
                    // STEP 6: ROLE = ADMIN
                    //
                    // Username = Mobile
                    // Password = Normal Employee Password
                    // =================================================

                    else if (roleName.Equals(
                        "Admin",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        isAdmin = true;

                        userName =
                            employee.Mobilenumber;

                        password =
                            normalEmployeePassword;
                    }


                    // =================================================
                    // STEP 7: ANY OTHER ROLE
                    //
                    // Manager
                    // Sales Executive
                    // Team Lead
                    // etc.
                    //
                    // Username = RoleMail
                    // Password = Decrypted RolePW
                    // =================================================

                    else
                    {
                        userName =
                            !string.IsNullOrWhiteSpace(
                                employee.RoleMail)
                                ? employee.RoleMail
                                : null;


                        if (!string.IsNullOrWhiteSpace(
                            employee.RolePW))
                        {
                            password =
                                Helper.Helper.DecryptAPIData(
                                    employee.RolePW,
                                    staticEncyKey
                                );
                        }
                        else
                        {
                            password = null;
                        }
                    }
                }


                // =====================================================
                // SUCCESS RESPONSE
                // =====================================================

                return Ok(new
                {
                    Status = true,

                    Message = "Login Successful.",

                    Data = new
                    {
                        // ---------------------------------------------
                        // EMPLOYEE
                        // ---------------------------------------------

                        EmployeeId =
                            employee.EmployeeId,

                        EmployeeCode =
                            employee.EmpCode,

                        FirstName =
                            employee.FirstName,

                        LastName =
                            employee.LastName,

                        EmployeeName =
                            ((employee.FirstName ?? "") + " " +
                             (employee.LastName ?? "")).Trim(),

                        Email =
                            employee.Email,

                        Mobile =
                            employee.Mobilenumber,


                        // ---------------------------------------------
                        // COMPANY
                        // ---------------------------------------------

                        CompanyID =
                            employee.CompanyId,

                        CompanyName =
                            companyName,


                        // ---------------------------------------------
                        // BRANCH / DEPARTMENT
                        // ---------------------------------------------

                        BranchId =
                            employee.BranchId,

                        DepartmentId =
                            employee.DepartmentId,


                        // ---------------------------------------------
                        // ADMIN
                        // ---------------------------------------------

                        IsAdmin =
                            isAdmin,


                        // ---------------------------------------------
                        // ROLE
                        // ---------------------------------------------

                        RoleId =
                            employee.RoleId,

                        RoleName =
                            roleName,


                        // ---------------------------------------------
                        // LOGIN / MAPPED CREDENTIALS
                        // ---------------------------------------------

                        UserName =
                            userName,

                        Password =
                            password
                    }
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Status = false,

                    Message =
                        ex.InnerException?.Message ??
                        ex.Message
                });
            }
        }
        public static string GenerateOTP()
        {
            byte[] bytes = new byte[4];
            RandomNumberGenerator.Fill(bytes);

            int otp = Math.Abs(BitConverter.ToInt32(bytes, 0)) % 900000 + 100000;

            return otp.ToString();
        }

        [HttpPost]
        [Route("SendRegOtp")]
        public IActionResult SendRegOtp([FromBody] SendOtpRequest request)
        {
            try
            {
                if (request == null)
                    return Ok(new { Status = false, Message = "Invalid request" });

                if (string.IsNullOrWhiteSpace(request.Email))
                    return Ok(new { Status = false, Message = "Email is required" });

                string otp = GenerateOTP();

                string fromMailID = _configuration["MailSettings:FromMailID"];
                string mailPassword = _configuration["MailSettings:MailPassword"];
                string mailServerHOST = _configuration["MailSettings:MailServerHOST"];
                string sendingPort = _configuration["MailSettings:SendingPort"];

                string subject = "OTP Verification Code";

                string body = $@"
            <p>Team {request.Name},</p>

            <p>Your One-Time Password (OTP) for verification is:</p>

            <h2 style='letter-spacing:4px;color:#2c3e50;'>{otp}</h2>

            <p>Please enter this OTP to continue the verification process.</p>

            <p>This OTP is confidential. Please do not share it with anyone.</p>

            <br/>
            <p>Regards,<br/>IMS Team</p>
        ";

                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient(mailServerHOST);

                mail.From = new MailAddress(fromMailID, "Hiring Team");
                mail.To.Add(request.Email);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;

                smtpServer.Port = Convert.ToInt32(sendingPort);
                smtpServer.Credentials = new NetworkCredential(fromMailID, mailPassword);
                smtpServer.EnableSsl = true;

                smtpServer.Send(mail);

                return Ok(new
                {
                    Status = true,
                    Message = "OTP sent successfully",
                    OTP = otp
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Status = false,
                    Message = ex.Message
                });
            }
        }

        [HttpPost]
        [Route("CheckDuplicateMobileNumber")]
        public IActionResult CheckDuplicateMobileNumber([FromBody] CheckMobileNumberRequest request)
        {
            try
            {
                if (request == null)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Request data is required"
                    });
                }

                if (string.IsNullOrWhiteSpace(request.MobileNumber))
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Mobile number is required"
                    });
                }

                string mobileNumber = request.MobileNumber.Trim();

                bool exists = dbContext.Companys.Any(x =>
                                    x.Mobile == mobileNumber)
                              ||
                              dbContext.EmployeeMasters.Any(x =>
                                    x.Mobilenumber == mobileNumber);

                if (exists)
                {
                    return Ok(new
                    {
                        Status = true,
                        Message = "Mobile number already exists"
                    });
                }

                return Ok(new
                {
                    Status = false,
                    Message = "Mobile number not exists"
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Status = false,
                    Message = ex.InnerException?.Message ?? ex.Message
                });
            }
        }
        public class CheckMobileNumberRequest
        {
            public string? MobileNumber { get; set; }
        }

        [HttpPost]
        [Route("CheckDuplicateEmail")]
        public IActionResult CheckDuplicateEmail([FromBody] CheckEmailRequest request)
        {
            try
            {
                if (request == null)
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Request data is required"
                    });
                }

                if (string.IsNullOrWhiteSpace(request.Email))
                {
                    return Ok(new
                    {
                        Status = false,
                        Message = "Email is required"
                    });
                }

                string email = request.Email.Trim().ToLower();

                bool exists = dbContext.Companys.Any(x =>
                                    x.Email != null &&
                                    x.Email.ToLower() == email)
                              ||
                              dbContext.EmployeeMasters.Any(x =>
                                    x.Email != null &&
                                    x.Email.ToLower() == email);

                if (exists)
                {
                    return Ok(new
                    {
                        Status = true,
                        Message = "Email already exists"
                    });
                }

                return Ok(new
                {
                    Status = false,
                    Message = "Email not exists"
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Status = false,
                    Message = ex.InnerException?.Message ?? ex.Message
                });
            }
        }


        public class CheckEmailRequest
        {
            public string? Email { get; set; }
        }


        public class SendOtpRequest
        {
            public string? Email { get; set; }
            public string? Name { get; set; }
        }


        ///=]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
        /// ///=]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
        ///  ///=]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
        ///   ///=]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
        ///    ///=]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
        ///    


        public class Companyreg
        {
            public string? CompanyCode { get; set; }
            public int? EpId { get; set; }
            public int companyID { get; set; }
            public string? CompanyName { get; set; }
            public string? FirstName { get; set; }
            public string? LastName { get; set; }
            public string? Email { get; set; }

            public string? Mobile { get; set; }

            public string? Website { get; set; }

            public string? GSTNo { get; set; }

            public string? PANNo { get; set; }

            public string? Address { get; set; }

            public string? City { get; set; }

            public string? State { get; set; }

            public string? Pincode { get; set; }

            public string? Logo { get; set; }

            public string? CompanyType { get; set; }

            public bool? IsActive { get; set; }
            public string? Password { get; set; }
            public DateTime? CreatedOn { get; set; }
            public List<int>? VehicleTypeIds { get; set; }
            public List<int>? BrandIds { get; set; }
        }
    }
}
