﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class Candidate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CandidateId { get; set; }

        public int CompanyId { get; set; }

      
        [MaxLength(100)]
        public string FirstName { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? MiddleName { get; set; }

        [MaxLength(100)]
        public string? LastName { get; set; }

        [MaxLength(256)]
        public string? Email { get; set; }

        [MaxLength(256)]
        public string? AlternateEmail { get; set; }

      
        [MaxLength(20)]
        public string MobileNumber { get; set; } = string.Empty;
        public string ResumePath { get; set; } = string.Empty;

        [MaxLength(20)]
        public string? AlternateMobileNumber { get; set; }

        [MaxLength(30)]
        public string? Gender { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DateOfBirth { get; set; }

        [MaxLength(1000)]
        public string? CurrentAddress { get; set; }

        [MaxLength(1000)]
        public string? PermanentAddress { get; set; }

        [MaxLength(150)]
        public string? CurrentCity { get; set; }

        [MaxLength(150)]
        public string? State { get; set; }

        [MaxLength(100)]
        public string? Country { get; set; }

        [MaxLength(20)]
        public string? Pincode { get; set; }

        // Professional information
        [MaxLength(200)]
        public string? CurrentCompany { get; set; }

        [MaxLength(150)]
        public string? CurrentDesignation { get; set; }

        [MaxLength(50)]
        public string? EmploymentStatus { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? TotalExperienceYears { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? RelevantExperienceYears { get; set; }

        // 0 means immediate joining; null means not supplied.
        public int? NoticePeriodDays { get; set; }

        [MaxLength(200)]
        public string? PreviousCompany { get; set; }

        [MaxLength(150)]
        public string? Industry { get; set; }

        [MaxLength(150)]
        public string? FunctionalArea { get; set; }

        // Education
        [MaxLength(150)]
        public string? HighestQualification { get; set; }

        [MaxLength(200)]
        public string? Specialization { get; set; }

        [MaxLength(250)]
        public string? University { get; set; }

        public int? PassingYear { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }
        public int? ModifiedBy { get; set; }
    }
}
