﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class RoleTemplateAssignments
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AssignmentId { get; set; }

        public int TemplateId { get; set; }

        public int RoleId { get; set; }

        public int HierarchyLevel { get; set; }

        public int EmployeeId { get; set; }
        public int CompanyId { get; set; }

        // References another AssignmentId in the same template.
        // Null means None / Top.
        public int? ReportingToAssignmentId { get; set; }

        public bool CanApprove { get; set; }
        public bool CanReject { get; set; }
        public bool CanReturn { get; set; }

        public string Stage { get; set; } = string.Empty;

        public int ApprovalDays { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }
        public int? ModifiedBy { get; set; }
    }
}
