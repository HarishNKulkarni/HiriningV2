﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class SkillFormDefinition
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SkillFormDefinitionId { get; set; }

        public int CategoryId { get; set; }

        public int SkillId { get; set; }

        public int Version { get; set; } = 1;

        [Column(TypeName = "nvarchar(max)")]
        public string DefinitionJson { get; set; } = "{}";

        public bool IsActive { get; set; } = true;

        public DateTime? CreatedOn { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }

        public int? ModifiedBy { get; set; }
    }
}
