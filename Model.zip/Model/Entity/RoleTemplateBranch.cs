﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class RoleTemplateBranch
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TemplateBranchId { get; set; }

        public int TemplateId { get; set; }

        public int BranchId { get; set; }
        public int CompanyId { get; set; }
    }
}
