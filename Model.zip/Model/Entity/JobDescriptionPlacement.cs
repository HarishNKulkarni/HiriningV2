﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class JobDescriptionPlacement
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlacementId { get; set; }

        public int CompanyId { get; set; }

        public int JobDescriptionId { get; set; }

        public int BranchId { get; set; }

        public int DepartmentId { get; set; }
    }
}
