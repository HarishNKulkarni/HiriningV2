﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class RoleTemplateAssignmentSkill
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AssignmentSkillId { get; set; }

        public int AssignmentId { get; set; }

        public int SkillId { get; set; }
        public int CompanyId { get; set; }
    }
}
