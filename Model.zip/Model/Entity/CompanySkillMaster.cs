﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class CompanySkillMaster
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CompanySkillMasterId { get; set; }

        // Parent: CompanySkillMapping.SkillMappingId
        public int SkillMappingId { get; set; }

        public int CompanyId { get; set; }

        public string SkillName { get; set; } = string.Empty;

        public bool IsActive { get; set; } = true;

        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public bool IsDisable { get; set; } = false;

        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
