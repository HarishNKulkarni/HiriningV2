﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeId { get; set; }

        public string? FirstName { get; set; }
        public string? LastName { get; set; }

        public int CompanyId { get; set; }
        public int BranchId { get; set; }
        public int DepartmentId { get; set; }

        public string? Password { get; set; }
        public string? Mobilenumber { get; set; }
        public string? Email { get; set; }
        public string? Profile { get; set; }

        public bool IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public int? RoleId { get; set; }

        public string? City { get; set; }
        public string? District { get; set; }
        public string? State { get; set; }
        public string? Location { get; set; }
        public string? RoleMail { get; set; }
        public string? RolePW { get; set; }

        public DateTime? DateOfJoining { get; set; }
        public string? EmergencyNumber { get; set; }

        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string? EmpCode { get; set; }
        public string? Designation { get; set; }
        public string? ReportingToManagerCode { get; set; }
        public string? Pan { get; set; }
        public string? Adhar { get; set; }
        public string? BankName { get; set; }
        public string? BankAccountNo { get; set; }
        public string? IFSC { get; set; }
        public bool? IsAdmin { get; set; }
        public int? EPID { get; set; }




    }
}
