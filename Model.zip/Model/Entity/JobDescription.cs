﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class JobDescription
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int JobDescriptionId { get; set; }

        public int CompanyId { get; set; }

        public int? TemplateId { get; set; }
        [MaxLength(200)]
        public string JobTitle { get; set; } = string.Empty;

        [MaxLength(250)]
        public string? Location { get; set; }

        [Required]
        [MaxLength(50)]
        public string EmploymentType { get; set; } = string.Empty;

        public int Vacancies { get; set; }

        [Column(TypeName = "date")]
        public DateTime? ApplicationDeadline { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? MinSalary { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? MaxSalary { get; set; }

        [MaxLength(3)]
        public string Currency { get; set; } = "INR";

        [MaxLength(20)]
        public string SalaryPeriod { get; set; } = "Year";

        [MaxLength(100)]
        public string? JobLevel { get; set; }

        // Position/title shown in the JD, e.g. "VP Engineering".
        [MaxLength(150)]
        public string? ReportingTo { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? MinExperienceYears { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? MaxExperienceYears { get; set; }

        public string? RoleOverview { get; set; }

        public string? Responsibilities { get; set; }

        public string? Qualifications { get; set; }

        public string? NiceToHave { get; set; }

        public string? PerksAndBenefits { get; set; }

        public int? InterviewRounds { get; set; }

        [MaxLength(50)]
        public string? InterviewMode { get; set; }

        public int? ExpectedJoiningDays { get; set; }
        public string? RequiredSkills { get; set; }

      

        [MaxLength(500)]
        public string? ImagePath { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }
        public int? ModifiedBy { get; set; }
    }
}
