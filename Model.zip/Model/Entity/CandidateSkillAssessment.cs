﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class CandidateSkillAssessment
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CandidateSkillAssessmentId { get; set; }

        public int CompanyId { get; set; }

        public int JobDescriptionId { get; set; }

        public int CandidateApplicationId { get; set; }

        // Identifies the skill, category and exact form version.
        public int SkillFormDefinitionId { get; set; }

        // RoleTemplateAssignment.AssignmentId.
        // Null for an admin assessment without an assignment.
        public int? AssignmentId { get; set; }

        // Employee whose assessment this record represents.
        public int AssessedByEmployeeId { get; set; }

        // Dynamic field answers only.
        // Score and Remarks are stored separately below.
        [Column(TypeName = "nvarchar(max)")]
        public string DetailsJson { get; set; } = "{}";

        [Column(TypeName = "decimal(5,2)")]
        public decimal? Score { get; set; }

        public string? Remarks { get; set; }

        // Pending, InProgress, Approved, Rejected, Returned.
        public string Status { get; set; } = "Pending";

        public bool IsActive { get; set; } = true;

        public DateTime? CreatedOn { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }

        public int? ModifiedBy { get; set; }
    }
}
