﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class CandidateApplication
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CandidateApplicationId { get; set; }

        public int CompanyId { get; set; }

        public int CandidateId { get; set; }

        public int JobDescriptionId { get; set; }

        public int? BranchId { get; set; }

        public int? DepartmentId { get; set; }

        // Position at the time of application.
        [MaxLength(200)]
        public string? AppliedPosition { get; set; }

        // Compensation captured for this application.
        [MaxLength(3)]
        public string Currency { get; set; } = "INR";

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CurrentCTC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CurrentFixedCTC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CurrentVariableCTC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? ExpectedCTC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? ExpectedFixedCTC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? ExpectedVariableCTC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CurrentMonthlySalary { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? ExpectedMonthlySalary { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? OfferedCTC { get; set; }

        public bool? IsNegotiable { get; set; }

        // Recruitment information
        [MaxLength(100)]
        public string? Source { get; set; }

        [MaxLength(200)]
        public string? ReferredBy { get; set; }

        public int? RecruiterEmployeeId { get; set; }

        public int? HiringManagerEmployeeId { get; set; }

        // Your company-scoped Cities master.
        public int? RecruitmentCityId { get; set; }

        [MaxLength(100)]
        public string? Cadre { get; set; }

        public bool? InterviewRequired { get; set; }

        [Column(TypeName = "date")]
        public DateTime? PreferredInterviewDate { get; set; }

        [MaxLength(250)]
        public string? PreferredLocation { get; set; }

        public bool? WillingToRelocate { get; set; }

        [MaxLength(500)]
        public string? CandidateAvailability { get; set; }

        public string? Remarks { get; set; }

        // Current recruitment stage.
        [MaxLength(50)]
        public string Stage { get; set; } = "Screening";

        // Current application outcome, separate from stage.
        [MaxLength(50)]
        public string Status { get; set; } = "Pending";

        public DateTime AppliedOn { get; set; } = DateTime.UtcNow;

        public bool IsActive { get; set; } = true;

        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }
        public int? ModifiedBy { get; set; }
    }
}
