﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class CandidateDocument
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CandidateDocumentId { get; set; }

        public int CompanyId { get; set; }

        public int CandidateApplicationId { get; set; }

        // Resume, Experience Letter, Qualification Certificate, etc.
        
        [MaxLength(100)]
        public string DocumentType { get; set; } = string.Empty;

       
        [MaxLength(255)]
        public string OriginalFileName { get; set; } = string.Empty;

        // Generated server-side storage reference.
        
        [MaxLength(500)]
        public string StorageKey { get; set; } = string.Empty;

        [MaxLength(150)]
        public string? ContentType { get; set; }

        public long FileSizeBytes { get; set; }

        public bool IsActive { get; set; } = true;

        // Upload audit information.
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }
        public int? ModifiedBy { get; set; }
    }
}
