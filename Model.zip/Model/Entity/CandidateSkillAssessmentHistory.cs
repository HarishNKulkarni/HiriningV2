﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class CandidateSkillAssessmentHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CandidateSkillAssessmentHistoryId { get; set; }

        public int CandidateSkillAssessmentId { get; set; }

        public int CompanyId { get; set; }

        public int JobDescriptionId { get; set; }

        public int CandidateApplicationId { get; set; }

        public int SkillFormDefinitionId { get; set; }

        public int? AssignmentId { get; set; }

        public int AssessedByEmployeeId { get; set; }

        // Save, Approve, Reject, Return.
        public string Action { get; set; } = string.Empty;

        public string? PreviousStatus { get; set; }

        public string NewStatus { get; set; } = string.Empty;

        // Answers at the time of this action.
        [Column(TypeName = "nvarchar(max)")]
        public string DetailsJson { get; set; } = "{}";

        [Column(TypeName = "decimal(5,2)")]
        public decimal? Score { get; set; }

        public string? Remarks { get; set; }

        // When the action occurred and who performed it.
        public DateTime CreatedOn { get; set; }

        public int CreatedBy { get; set; }

        public bool IsRemarkAdded { get; set; }
    }
}
