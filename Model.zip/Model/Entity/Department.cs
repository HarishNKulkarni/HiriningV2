﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recruitment.Model.Entity
{
    public class Department
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int DepartmentId { get; set; }

        public string? DepartmentName { get; set; }
        public int BranchId { get; set; }
        public int CompanyId { get; set; }

        public string? Location { get; set; }
        public string? City { get; set; }
        public string? District { get; set; }
        public string? State { get; set; }

        public DateTime? CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public int? CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }

        public bool IsActive { get; set; }
    }
}
