﻿using Microsoft.EntityFrameworkCore;
using Recruitment.Model.Entity;

namespace Recruitment.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Company> Companys { get; set; }
        public DbSet<Branch> Branches { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> EmployeeMasters { get; set; }
        public DbSet<Role> Roles { get; set; } = null!;
        public DbSet<SkillCategory> SkillCategories { get; set; } = null!;
        public DbSet<SkillMaster> SkillMasters { get; set; } = null!;

        public DbSet<RoleTemplate> RoleTemplates { get; set; } = null!;

        public DbSet<RoleTemplateBranch> RoleTemplateBranches { get; set; } = null!;

        public DbSet<RoleTemplateAssignments> RoleTemplateAssignment { get; set; } = null!;

        public DbSet<RoleTemplateAssignmentSkill> RoleTemplateAssignmentSkills { get; set; } = null!;

        public DbSet<City> Cities { get; set; } = null!;
        public DbSet<Module> Modules { get; set; } = null!;
        public DbSet<EmployeeModuleAccess> EmployeeModuleAccesses{  get;  set;} = null!;
        public DbSet<JobDescription> JobDescriptions { get; set; } = null!;

        public DbSet<JobDescriptionPlacement> JobDescriptionPlacements{ get; set;} = null!;
        public DbSet<Candidate> Candidates { get; set; } = null!;

        public DbSet<CandidateApplication> CandidateApplications { get; set; } = null!;

        public DbSet<CandidateDocument> CandidateDocuments {get;set; } = null!;
        public DbSet<SkillFormDefinition> SkillFormDefinitions { get; set; }
        public DbSet<CandidateSkillAssessment> CandidateSkillAssessments  {get; set; }

        public DbSet<CandidateSkillAssessmentHistory> CandidateSkillAssessmentHistories{ get;set; }
        public DbSet<CompanySkillMapping> CompanySkillMappings { get; set; }
        public DbSet<CompanySkillMaster> CompanySkillMasters { get; set; }

    }
}
